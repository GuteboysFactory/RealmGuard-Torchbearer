import { RealmGuardActorSheet } from "./actor-sheet.mjs";
import { isDefaultSkill } from "../module/default-skills.mjs";

export class RealmGuardNpcSheet extends RealmGuardActorSheet {
  static DEFAULT_OPTIONS = {
    ...super.DEFAULT_OPTIONS,
    classes: ["realm-guard", "actor-sheet", "npc-sheet"],
    position: { width: 760, height: 720 },
    actions: {
      ...super.DEFAULT_OPTIONS.actions,
      clearNpcSkill: RealmGuardNpcSheet._clearNpcSkill
    }
  };

  static PARTS = {
    main: { template: "systems/realm-guard/templates/actor/npc.hbs" }
  };

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const iconForGear = name => {
      const value = String(name ?? "").toLowerCase();
      if (value.includes("shield")) return "fa-solid fa-shield-halved";
      if (value.includes("bow") || value.includes("sling")) return "fa-solid fa-bullseye";
      if (value.includes("sword") || value.includes("axe") || value.includes("dagger") || value.includes("knife") || value.includes("spear") || value.includes("halberd")) return "fa-solid fa-khanda";
      if (value.includes("mail") || value.includes("armor") || value.includes("armour") || value.includes("cloak")) return "fa-solid fa-shirt";
      if (value.includes("helmet") || value.includes("helm")) return "fa-solid fa-helmet-safety";
      return "fa-solid fa-box-open";
    };
    const locationLabel = item => {
      const inv = item.system?.inventory ?? {};
      const location = String(inv.location ?? "");
      const labels = {
        "left-hand": "Left Hand", "right-hand": "Right Hand", torso: "Torso", head: "Head", cloak: "Cloak", belt: "Belt", neck: "Neck", feet: "Feet", pocket: "Pocket"
      };
      if (labels[location]) return labels[location];
      if (inv.containerId) return "Packed";
      return "Unassigned";
    };
    return foundry.utils.mergeObject(context, {
      npcGear: (this.actor.gear ?? []).map(item => ({
        id: item.id,
        name: item.name,
        iconClass: iconForGear(item.name),
        locationLabel: locationLabel(item),
        quantityLabel: Number(item.system?.quantity ?? 1) > 1 ? `x${Number(item.system.quantity)}` : "",
        system: item.system
      }))
    }, { inplace: false });
  }

  static async _clearNpcSkill(event, target) {
    const id = target.closest("[data-item-id]")?.dataset.itemId;
    const role = this.actor.items.get(id);
    if (!role || role.type !== "role") return;
    if (isDefaultSkill(role)) {
      await role.update({
        "system.rating": 0,
        "system.learning.passed": 0,
        "system.learning.failed": 0,
        "system.beginnerAttempts": 0
      });
    } else {
      await this.actor.deleteEmbeddedDocuments("Item", [role.id]);
    }
    await this.render({ force: true });
  }
}
