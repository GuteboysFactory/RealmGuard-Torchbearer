const TOOL_REGISTRY = new Map();
const DOCK_ID = "rg-gm-dock";
let resizeObserver = null;
let mutationObserver = null;
let observedHotbar = null;
let positionFrame = null;
let retryTimer = null;

function esc(value) {
  return foundry.utils.escapeHTML(String(value ?? ""));
}

export function registerGmDockTool({ id, icon, tooltip, order = 100, visible = null, onClick }) {
  if (!id || typeof onClick !== "function") throw new Error("Realm Guard / Torchbearer GM Dock tool requires id and onClick.");
  TOOL_REGISTRY.set(id, {
    id,
    icon: icon || "fa-solid fa-toolbox",
    tooltip: tooltip || id,
    order,
    visible: typeof visible === "function" ? visible : () => true,
    onClick
  });
  if (game?.ready) renderGmDock();
}

function getHotbarElement() {
  const hotbar = ui?.hotbar?.element;
  if (hotbar instanceof HTMLElement) return hotbar;
  return document.querySelector("#hotbar");
}

function removeDock() {
  document.getElementById(DOCK_ID)?.remove();
  resizeObserver?.disconnect();
  mutationObserver?.disconnect();
  resizeObserver = null;
  mutationObserver = null;
  observedHotbar = null;
}

function schedulePosition() {
  if (positionFrame) cancelAnimationFrame(positionFrame);
  positionFrame = requestAnimationFrame(() => {
    positionFrame = null;
    positionDock();
  });
}

function observeHotbar(hotbar) {
  if (observedHotbar === hotbar) return;
  resizeObserver?.disconnect();
  mutationObserver?.disconnect();
  observedHotbar = hotbar;

  resizeObserver = new ResizeObserver(() => schedulePosition());
  resizeObserver.observe(hotbar);

  mutationObserver = new MutationObserver(() => schedulePosition());
  mutationObserver.observe(hotbar, { attributes: true, childList: true, subtree: true });
}

function positionDock() {
  const dock = document.getElementById(DOCK_ID);
  const hotbar = getHotbarElement();
  if (!dock || !hotbar) return;

  const gap = 8;
  const edge = 8;
  const hotbarRect = hotbar.getBoundingClientRect();
  const dockRect = dock.getBoundingClientRect();

  let placement = "right";
  let left = hotbarRect.right + gap;
  let top = hotbarRect.bottom - dockRect.height;

  if (left + dockRect.width > window.innerWidth - edge) {
    placement = "left";
    left = hotbarRect.left - gap - dockRect.width;
  }

  if (left < edge) {
    placement = "above";
    left = Math.min(Math.max(edge, hotbarRect.right - dockRect.width), window.innerWidth - dockRect.width - edge);
    top = hotbarRect.top - gap - dockRect.height;
  }

  top = Math.min(Math.max(edge, top), window.innerHeight - dockRect.height - edge);
  dock.dataset.placement = placement;
  dock.style.left = `${Math.round(left)}px`;
  dock.style.top = `${Math.round(top)}px`;
}

function buildDock() {
  let dock = document.getElementById(DOCK_ID);
  if (!dock) {
    dock = document.createElement("aside");
    dock.id = DOCK_ID;
    dock.className = "rg-gm-dock";
    dock.setAttribute("role", "toolbar");
    dock.setAttribute("aria-label", "Realm Guard / Torchbearer GM Dock");
    document.body.append(dock);
  }

  const tools = [...TOOL_REGISTRY.values()]
    .filter(tool => {
      try { return tool.visible?.() !== false; }
      catch (_error) { return true; }
    })
    .sort((a, b) => a.order - b.order || a.id.localeCompare(b.id));
  dock.innerHTML = `<span class="rg-gm-dock-brand" title="Realm Guard / Torchbearer GM Dock" data-tooltip="Realm Guard / Torchbearer GM Dock">RG/TB</span>${tools.map(tool => `
    <button type="button" class="rg-gm-dock-tool" data-rg-gm-tool="${esc(tool.id)}" title="${esc(tool.tooltip)}" data-tooltip="${esc(tool.tooltip)}" data-tooltip-direction="UP" aria-label="${esc(tool.tooltip)}">
      <i class="${esc(tool.icon)}"></i>
    </button>`).join("")}`;

  for (const button of dock.querySelectorAll("[data-rg-gm-tool]")) {
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      const tool = TOOL_REGISTRY.get(button.dataset.rgGmTool);
      if (!game.user?.isGM || !tool) return;
      void tool.onClick();
    });
  }
  return dock;
}

export function renderGmDock(attempt = 0) {
  clearTimeout(retryTimer);
  if (!game.user?.isGM) {
    removeDock();
    return;
  }

  const hotbar = getHotbarElement();
  if (!hotbar) {
    if (attempt < 20) retryTimer = setTimeout(() => renderGmDock(attempt + 1), 150);
    return;
  }

  buildDock();
  observeHotbar(hotbar);
  schedulePosition();
}

export function installGmDock() {
  Hooks.once("ready", () => renderGmDock());
  Hooks.on("renderHotbar", () => renderGmDock());
  window.addEventListener("resize", schedulePosition, { passive: true });
}
