# Realm Guard / Torchbearer v1.0.1 - World Info Hotfix Test Protocol

**Foundry target:** VTT 13.351  
**Baseline:** v1.0.0 GOLD  
**Build status:** QA  
**Scope:** Join Page World Description only; no gameplay/rules changes

> **STOP RULE:** Reject v1.0.1 if the Join Page no longer loads, the Realm Guard background disappears, Foundry's saved World Description is not visible, Join controls become unusable, the internal system id changes, or any core v1.0.0 smoke test regresses.

## 1. Install / identity

- [ ] Back up the v1.0.0 test World.
- [ ] Upgrade v1.0.0 -> v1.0.1.
- [ ] Foundry reports **Realm Guard / Torchbearer v1.0.1**.
- [ ] Internal package id is still `realm-guard`.
- [ ] Existing World content and permissions remain intact.

## 2. World Description - populated

1. Return to Setup and choose **Edit World**.
2. In **World Description**, enter a short unique test sentence, for example: `Welcome Rangers - v1.0.1 World Info test.`
3. Apply simple rich-text formatting to at least one word.
4. Click **Update World** and launch the World.

- [ ] The Join Page shows the exact saved World Description text.
- [ ] The text is readable over the Realm Guard / Torchbearer background.
- [ ] Rich-text formatting renders normally rather than as raw HTML.
- [ ] No hard-coded Realm Guard system-description paragraph is appended automatically.

## 3. World Description - edit / persistence

- [ ] Change the World Description in Edit World and save again.
- [ ] Relaunch the World.
- [ ] The new description replaces the old text on the Join Page.
- [ ] The system has not overwritten or restored any previous description.

## 4. World Description - empty

- [ ] Clear World Description completely and save.
- [ ] Relaunch the World.
- [ ] No system-owned fallback copy appears.
- [ ] Join Page layout remains usable with an empty description.

## 5. Join Page regression

- [ ] Approved clean Realm Guard / Torchbearer background still displays.
- [ ] World title remains Foundry's live editable World title.
- [ ] Select Player, Access Key and Join Game controls remain readable/clickable.
- [ ] Return to Setup remains usable for the GM.
- [ ] Layout remains acceptable at normal desktop width and a narrower browser width.

## 6. v1.0.0 core smoke test

After login:

- [ ] Existing Ranger sheet opens.
- [ ] Existing NPC sheet opens.
- [ ] One normal Skill/Ability roll resolves to chat.
- [ ] Conditions controls open.
- [ ] Inventory & Gear opens.
- [ ] Global RG/TB Manual button opens the Manual.
- [ ] World Health Audit reports system version **1.0.1** without a version-mismatch warning.

## Result

- [ ] **PASS / GOLD**
- [ ] **FAIL / FIX REQUIRED**

Notes:

