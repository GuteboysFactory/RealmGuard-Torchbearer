# Realm Guard / Torchbearer v1.0.1 - Static QA

**Target:** Foundry VTT 13.351  
**Baseline:** v1.0.0 GOLD  
**Layer:** World Info / Join Page hotfix

## Result

**PASS - ready for live Foundry v1.0.1 QA.**

## Checks performed

- All `.mjs` files pass `node --check` syntax validation.
- `system.json` and `lang/en.json` parse as valid JSON.
- All relative ES-module imports resolve to files present in the package.
- `system.json` retains internal id `realm-guard`, title `Realm Guard / Torchbearer`, Foundry target 13.351 and now reports version `1.0.1`.
- Runtime initialization, Rules Reference release label and World Health Audit version expectation are aligned to `1.0.1`.
- The approved Join Page background asset is retained at the same package path and remains a 1944x809 WebP.
- Join Page styling remains scoped to `#join-game` / pages containing `#join-game`.
- The v1.0.0 hard-coded `#world-description::after` system-copy payload has been removed.
- `#world-description` and its rich-text children receive explicit visibility, opacity and readable foreground styling.
- Pseudo-elements on the World Description panel are explicitly disabled so no system-owned text is appended.
- No World migration or World-description write path was added.
- `TEST_PROTOCOL_v1.0.1.md` is included and the v1.0.0 version-specific QA documents are not carried forward.

## Deliberate live-QA boundary

Static QA cannot prove what Foundry v13.351 renders from an actual saved World Description. Live QA must therefore verify three states: populated/rich-text description, edited description after relaunch, and intentionally empty description. It must also verify that Join/Return controls remain usable and run the short v1.0.0 core smoke test.

## Data-safety note

v1.0.1 is presentation-only. It does not create, overwrite or migrate `World Description`, Actors, Items, Journals, Scenes, Compendiums, progression, Conflict/session state or permissions.
