import { RealmGuardActorSheet } from "./actor-sheet.mjs";
import { isDefaultSkill } from "../module/default-skills.mjs";

export class RealmGuardNpcSheet extends RealmGuardActorSheet {
  static DEFAULT_OPTIONS = {
    ...super.DEFAULT_OPTIONS,
    classes: ["realm-guard", "actor-sheet", "npc-sheet"],
    position: { width: 900, height: 720 },
    actions: {
      ...super.DEFAULT_OPTIONS.actions,
      clearNpcSkill: RealmGuardNpcSheet._clearNpcSkill
    }
  };

  static PARTS = {
    main: { template: "systems/realm-guard/templates/actor/npc.hbs" }
  };

  _onRender(context, options) {
    super._onRender(context, options);
    const root = this.element;
    if (!root || !this.isEditable) return;
    const allowed = new Set(["role", "wise", "trait", "gear", "condition", "talent", "tokenOfPower"]);
    const sectionFor = type => ({ role: ".rg-npc-skills", wise: ".rg-npc-wises", trait: ".rg-npc-side", gear: ".rg-npc-side", condition: ".rg-npc-side", talent: ".rg-npc-talents", tokenOfPower: ".rg-npc-token-panel" }[type] || ".rg-npc-sheet");
    const dragData = event => { try { return globalThis.TextEditor?.getDragEventData?.(event) ?? {}; } catch (_e) { return {}; } };
    const resolveItem = async data => {
      if (data?.type !== "Item") return null;
      const impl = Item.implementation ?? Item;
      if (typeof impl.fromDropData === "function") return await impl.fromDropData(data);
      if (data.uuid) return await fromUuid(data.uuid);
      return null;
    };
    let highlighted = null;
    root.addEventListener("dragover", event => {
      const data = dragData(event);
      if (data?.type !== "Item") return;
      event.preventDefault();
      root.classList.add("rg-npc-drop-active");
    });
    root.addEventListener("dragleave", event => { if (!root.contains(event.relatedTarget)) { root.classList.remove("rg-npc-drop-active"); highlighted?.classList.remove("rg-npc-drop-target"); highlighted = null; } });
    root.addEventListener("drop", async event => {
      const data = dragData(event);
      const item = await resolveItem(data);
      if (!item || !allowed.has(item.type)) return;
      event.preventDefault(); event.stopPropagation();
      root.classList.remove("rg-npc-drop-active");
      const targetSection = root.querySelector(sectionFor(item.type)); targetSection?.classList.add("rg-npc-drop-target"); setTimeout(()=>targetSection?.classList.remove("rg-npc-drop-target"),500);
      const duplicate = this.actor.items.find(existing => existing.type === item.type && existing.name.toLowerCase() === item.name.toLowerCase());
      if (duplicate) {
        const choice = await foundry.applications.api.DialogV2.wait({ window:{title:"Realm Guard · NPC Drop"}, modal:false, rejectClose:false, content:`<div class="rg-npc-drop-confirm"><h3>${foundry.utils.escapeHTML(item.name)}</h3><p>This NPC already has a ${foundry.utils.escapeHTML(item.type)} with the same name.</p></div>`, buttons:[{action:"replace",label:"Replace",default:true,callback:()=>"replace"},{action:"cancel",label:"Cancel",callback:()=>null}] });
        if (choice !== "replace") return;
        await duplicate.delete();
      }
      const source = item.toObject(); delete source._id; source.flags = foundry.utils.deepClone(source.flags ?? {});
      await this.actor.createEmbeddedDocuments("Item", [source]);
      ui.notifications.info(`Realm Guard: ${item.name} added to ${this.actor.name}.`);
      await this.render({ force:true });
    });
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const iconForGear = name => {
      const value = String(name ?? "").toLowerCase();
      if (value.includes("shield")) return "fa-solid fa-shield-halved";
      if (value.includes("bow") || value.includes("sling")) return "fa-solid fa-bullseye";
      if (value.includes("sword") || value.includes("axe") || value.includes("dagger") || value.includes("knife") || value.includes("spear") || value.includes("halberd")) return "fa-solid fa-khanda";
      if (value.includes("mail") || value.includes("armor") || value.includes("armour") || value.includes("cloak")) return "fa-solid fa-shirt";
      if (value.includes("helmet") || value.includes("helm")) return "fa-solid fa-helmet-safety";
      return "fa-solid fa-box-open";
    };
    const locationLabel = item => {
      const inv = item.system?.inventory ?? {};
      const location = String(inv.location ?? "");
      const labels = {
        "left-hand": "Left Hand", "right-hand": "Right Hand", torso: "Torso", head: "Head", cloak: "Cloak", belt: "Belt", neck: "Neck", feet: "Feet", pocket: "Pocket"
      };
      if (labels[location]) return labels[location];
      if (inv.containerId) return "Packed";
      return "Unassigned";
    };
    return foundry.utils.mergeObject(context, {
      npcGear: (this.actor.gear ?? []).map(item => ({
        id: item.id,
        name: item.name,
        iconClass: iconForGear(item.name),
        locationLabel: locationLabel(item),
        quantityLabel: Number(item.system?.quantity ?? 1) > 1 ? `x${Number(item.system.quantity)}` : "",
        system: item.system
      }))
    }, { inplace: false });
  }

  static async _clearNpcSkill(event, target) {
    const id = target.closest("[data-item-id]")?.dataset.itemId;
    const role = this.actor.items.get(id);
    if (!role || role.type !== "role") return;
    if (isDefaultSkill(role)) {
      await role.update({
        "system.rating": 0,
        "system.learning.passed": 0,
        "system.learning.failed": 0,
        "system.beginnerAttempts": 0
      });
    } else {
      await this.actor.deleteEmbeddedDocuments("Item", [role.id]);
    }
    await this.render({ force: true });
  }
}
