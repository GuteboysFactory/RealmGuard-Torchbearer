# Realm Guard / Torchbearer for Foundry VTT

**Version:** 1.0.8.3 - NPC Layout & Token Portrait Hotfix
**Target:** Foundry VTT 13.351  
**Status:** QA
**Verified GOLD baseline:** v1.0.7.1





## v1.0.8.3 NPC Layout & Token Portrait Hotfix

- **Compact GM Notes:** GM Notes now lives inside the NPC sheet's left column beneath Quick Skills instead of spanning the full sheet width.
- **Token becomes NPC portrait on explicit save:** Create / Save Token still remains the only commit action. For NPCs, the generated round PNG now becomes both prototype-token art and the NPC Actor portrait.
- **Original artwork is preserved:** Token Builder stores the full source artwork separately so later edits still begin from the original image rather than from the already-cropped round token.

## v1.0.8.2 Token Builder & NPC Conditions Hotfix

- Carries forward the full v1.0.8 Rules, NPC & Token Polish scope plus the v1.0.8.1 Roll Dialog grouping fix.
- **Manual Token Builder framing:** Token Builder starts from the full Actor portrait, lets the user move the entire source image and zoom freely, and keeps Center/Fit/Fill/drag/zoom as preview-only actions.
- **Explicit commit:** no Actor or Scene token is changed until **Create / Save Token** is pressed. Save renders the chosen framing into the real round PNG, updates the prototype token and can optionally update matching tokens on the current Scene.
- **NPC Template handoff:** image-drop creates the NPC and portrait but does not auto-commit a final round crop. The GM decides the framing in Token Builder.
- **NPC Conditions cosmetic fix:** the compact NPC Conditions panel now uses readable single-column rows with full labels and aligned controls.
- No destructive Actor/World migration.

**v1.0.8.2 is QA. v1.0.7.1 remains the verified GOLD baseline until live QA passes.**

Use `TEST_PROTOCOL_v1.0.8.2.md` for live QA. Static verification is recorded in `STATIC_QA_v1.0.8.2.md`.

## v1.0.8 Rules, NPC & Token Polish

- Corrects beneficial **Trait** use to Mouse Guard 2E session rules: Level 1 = +1D once/session, Level 2 = +1D twice/session, Level 3 = +1s on relevant passed/tied tests. Level 1/2 uses are enforced automatically and reset when End Session is finalized.
- Keeps **Trait Against** separate from beneficial use tracking and leaves unrated Wises on their existing once-per-test effect model.
- Fixes duplicate `NEW SKILL LEARNED` chat publication during automatic Beginner's Luck learning, including multi-client sheet races.
- Simplifies the Roll Dialog top row to **Obstacle | Modifier (automatic) | Extra Dice**. Accepted Help remains automatic in the Teamwork section; Extra Dice is explicitly manual/situational.
- Adds **Quick Token Builder** for Rangers and NPCs with drag positioning, zoom, Center, Fit/Fill, token size and Use Portrait as Token. The preview remains non-destructive until Create / Save Token is pressed; that action bakes the chosen framing into a real circular PNG and can refresh matching tokens on the current Scene.
- NPC template image-spawn keeps the dropped image as portrait and an aspect-safe temporary prototype token; the final round crop is created manually in Token Builder.
- Polishes the NPC sheet header, resource alignment, stat spacing, quick tools, drop hint and responsive layout.
- Preserves the v1.0.7.1 dice presentation and narrow chat-result layout fixes.

**v1.0.8 is QA. v1.0.7.1 remains the verified GOLD baseline until live QA passes.**

Use `TEST_PROTOCOL_v1.0.8.md` for live QA. Static verification is recorded in `STATIC_QA_v1.0.8.md`.

## v1.0.7 Flexible Test Engine & GM Flow

- Adds **Custom Roll**. Linked Skill/Ability choices re-use the standard automated Roll Dialog; a free dice pool supports improvised tests without automatic Learning.
- Separates **Baseline Obstacle** from **Change Live Roll OB**. The live GM control pushes instantly to currently open Baseline-linked ordinary roll dialogs and can reset to Baseline.
- Removes the manual untrained Skill **LEARN** step. The final Beginner's Luck attempt now learns the Skill automatically at Rating 2 and posts a large celebration card.
- Makes Roll **Modifier (automatic)** read-only and explains the Condition/system modifier. Manual additions remain in Extra Dice.
- Makes roll results visual: 1-3 red, 4-5 green, and 6 green with a star for Open 6s visibility.
- Adds **Smart NPC Drag & Drop** for Skills, Wises, Traits, Gear, Conditions, Talents and Tokens of Power.
- Adds **NPC Templates & Quick Spawn**. A GM can create a copy from a template or drop an image file onto a template to create the NPC with the template stats/items and the image as portrait; the GM can then frame the final round token in Token Builder.
- Adds step-by-step **Conflict chat results** for each resolved Action, including both sides' dice/successes and Disposition before/after.

**v1.0.7.1 passed dedicated live QA and is the verified GOLD baseline for v1.0.8.**

## v1.0.6 Playflow, Advancement & Conflict UX

- Adds visible automatic Pass/Fail advancement for Nature, Will, Health, Resources and Circles. Nature uses Maximum Nature; Beginner's Luck does not advance its Will/Health base Ability.
- Rebuilds normal Roll Dialog Teamwork as a player-to-player **Help Request**: the roller clicks Help, active Ranger players answer in their own non-modal prompt, and accepted Help is added live to the roll. Normal Skill/Ability Help remains distinct from **I Am Wise**; optional Torchbearer-inspired **Synergy** is chosen by the helper and is bound to the helper's own Fate/source.
- Adds live **Baseline Obstacle** and Obstacle workflow mode controls to GM Control. Optional GM approval uses a compact non-modal request with live Ob updates to the player's Roll Dialog.
- Adds source-backed Ob difficulty guidance without inventing Skill factors. Versus and rule-specific tests keep their own Ob/opposition logic.
- Repairs/hardens the Conflict hidden-plan transition, auto-reveals actions when safe, reduces unnecessary Reveal clicks, adds current-step guidance, a compact **Conflict Action Guide** above the planning cards, and exchange history. The guide explains what Attack/Defend/Feint/Maneuver do, what each is good for and its main drawback without requiring the manual.
- Adds contextual tooltips/inline explanations and explicit unavailable-resource reasons.
- Corrects the remaining Nature-management modal regression so normal RG/TB windows remain non-modal.
- No destructive Actor/World schema migration. Ability learning state is stored non-destructively in Realm Guard Actor flags.

**v1.0.6 passed live QA and is the GOLD baseline for v1.0.7.**


## v1.0.5 Gameplay & UI Polish Hotfix

- Realm Guard / Torchbearer DialogV2 workflows are non-modal so an open system window no longer blocks interaction with the rest of Foundry.
- Beginner's Luck can **Tap Nature** (except the existing Resources/Circles exclusions); Nature dice are added **after** the Beginner's Luck halving and use the normal Within/Against Nature tax rules.
- Trained Skill advancement is now **automatic** as soon as required Pass and Fail marks are present. The manual Advance button is removed so additional eligible tests are not lost while waiting for a click.
- Skill advancement chat is rebuilt as a dark, celebratory **Congratulations** card.
- Character Level advancement remains immediate when cumulative spent Fate/Persona crosses a threshold. Level-up chat is now a large celebration card and an available Talent choice opens automatically without delaying the level increase.
- GM Dock can be dragged to another screen position. Its position is saved per user and a Reset Position control restores the normal hotbar-adjacent placement.
- Full RG/TB chat presentation audit: system-generated messages claim a consistent dark Realm Guard surface, including the Foundry message wrapper, so light-theme white cards no longer undermine readability.
- v1.0.4 Recruitment House Rule UX remains included.

## v1.0.4 Recruitment House Rule UX

This patch keeps the printed Realm Guard Recruitment restriction as the default while adding an explicit opt-in table variant:

- **Allow Servants of the Enemy as personal Enemies (House Rule)** is available in Recruitment Step 9.
- The option is **off by default**. With it off, the printed-rule Free Peoples choices remain the intended path.
- When enabled, the Ranger may choose **Orc, Troll, Warg, Spider or another servant of the Enemy** as the recurring personal Enemy.
- The Enemy selector is relabelled **Enemy's People / Type** and includes a short explanation so the question is less ambiguous.
- House-rule use is preserved in Recruitment metadata on the created Actor; no Actor schema migration is required.

## v1.0.3 GM Playtest hotfix

This patch addresses the first external GM playtest feedback without changing World data or introducing a migration:

- Persona spending is now selectable from **0-3 points** for **+0D to +3D** on supported rolls.
- Teamwork no longer offers a helper's **Trait**. Helpers can use an appropriate trained **Skill**, or a relevant **Wise** for +1D through *I Am Wise*.
- Nature wording now uses **Test is: Within Nature descriptors / Against Nature descriptors** instead of the ambiguous Relationship label.
- End of Session allows **Embodiment** for the sole Ranger in a one-player session; the normal not-everyone restriction remains for groups of two or more.
- Realm Guard chat cards get a theme-independent high-contrast fallback so cards such as **ADVANCEMENT** remain readable in Foundry's light chat presentation.
- v1.0.2's sidebar Manual launcher and v1.0.1 Join Page behavior are retained.

## v1.0.2 Sidebar Manual UI hotfix

The previous floating **RG/TB** pill has been removed. The global Manual & Rules Reference launcher is now an icon-only **book button inside Foundry's sidebar tab strip**, using Foundry's own `ui-control` styling where available. The button keeps the same manual-opening behavior and tooltip without floating over the canvas/chat area.

The v1.0.1 World Description behavior is retained: Foundry's native **Edit World > World Description** remains the single source for Join Page World Description text. No automatic World Description content is seeded.

## v1.0 identity

The visible system name is now **Realm Guard / Torchbearer**. The internal Foundry package id remains `realm-guard` so existing Worlds continue to identify the same game system after upgrading from the verified 0.x line.

This private game system deliberately combines:

1. **Realm Guard: Rangers of the North** rules where that hack defines/overrides play;
2. inherited **Mouse Guard RPG 2nd Edition** core mechanics where Realm Guard does not replace them;
3. selected compatible **Torchbearer 2nd Edition** ideas that were deliberately adopted; and
4. clearly marked **Realm Guard / Torchbearer Foundry expansions**.

The release is not presented as a one-to-one digital edition of any single source book.


## Join page presentation

v1.0.3 retains the v1.0.1 dedicated **Realm Guard / Torchbearer** world/login background and uses Foundry's native **World Description** as the authoritative Join Page text. The system manifest still declares the same artwork as the default background for new Realm Guard / Torchbearer Worlds. Existing Worlds keep their World data; the join-page theme is presentation-only and does not move, rewrite or auto-fill campaign content.

## Global Manual & Rules Reference

v1.0.3 retains the icon-only **book button in Foundry's sidebar** for every user. The manual can be opened while working elsewhere in Foundry instead of requiring a return to chat.

The integrated manual now has two layers:

- **Using the Foundry System** - where the tools live and how the implemented play loop works.
- **Rules Reference** - concise summaries of the rules and automation boundaries actually used by the system.

Rules are marked as:

- `RULE`
- `AUTOMATED`
- `GM CALL`
- `RG/TB FOUNDRY`

## Permanent Rules Reference Journal

On first GM load, v1.0 creates a player-readable Journal folder **Realm Guard / Torchbearer** and the Journal **Realm Guard / Torchbearer - Rules Reference** if it does not already exist.

Normal world loading does not overwrite an existing Rules Reference Journal.

The same v1.0 rules-reference definitions are used by the integrated manual and the seeded Journal.

Shipped text references:

- `SYSTEM_MANUAL.md`
- `RULES_REFERENCE.md`

## Existing v0.26 GOLD features retained

- Recruitment 2.0 / Create Ranger / Recruitment Guide
- Skills, Learning, Beginner's Luck, Nature, Traits, Wises, Teamwork, Fate/Persona
- Conditions, Recovery, Optional Turn Manager / Free Play
- Inventory & Gear paper-doll and Containers
- Tokens of Power
- Levels & Talents
- Card-driven Conflict Engine
- Quick NPC / compact NPC sheet / GM Control
- Starter Compendiums
- GM Content Studio
- End of Session
- World Health Audit
- non-destructive World upgrade/transfer policy

## Data preservation

v1.0 does not rename the internal system id and does not deliberately move/reset existing World data. Existing Actors, NPCs, Scenes, Journals, Items, Compendiums, Recruitment, Inventory, Conditions, Tokens, Talents and progression must remain intact.

v1.0.7.1 is the current verified GOLD baseline while v1.0.8 is tested.

### Final v1.0 Join Game correction
v1.0.3 keeps the approved ultra-wide Realm Guard / Torchbearer release artwork while restoring Foundry's native World Description as the authoritative Join Page text source. Join Game layout styling aligns the live Foundry controls with the artwork without injecting campaign/system copy into the description panel.

## Project repository
Distribution repository: https://github.com/GuteboysFactory/RealmGuard-Torchbearer

Public updates use the repository manifest. The public manifest should remain on the verified GOLD release until v1.0.8 passes QA.

### Join Page World Description
Realm Guard / Torchbearer v1.0.3 displays the description saved in Foundry under **Edit World > World Description**. If the GM leaves that field blank, the Join Page description content is intentionally blank. The system does not write to the World document.

