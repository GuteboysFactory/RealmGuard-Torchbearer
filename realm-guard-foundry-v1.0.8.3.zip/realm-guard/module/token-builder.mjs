const NS = "realm-guard";

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, Number(value ?? 0)));
}

function esc(value) {
  return foundry.utils.escapeHTML(String(value ?? ""));
}

function tokenTexture(actor) {
  return actor?.prototypeToken?.texture ?? {};
}

function safeFilePart(value = "token") {
  const clean = String(value || "token")
    .normalize?.("NFKD")
    ?.replace(/[\u0300-\u036f]/g, "") ?? String(value || "token");
  return clean.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64) || "token";
}

async function ensureTokenArtDirectory(picker) {
  const nested = "realm-guard/token-art";
  const fallback = "realm-guard-token-art";
  for (const dir of ["realm-guard", nested]) {
    try { await picker.createDirectory?.("data", dir, {}, { notify: false }); }
    catch (_error) { /* existing directory is expected */ }
  }
  if (picker.browse) {
    try { await picker.browse("data", nested, {}); return nested; }
    catch (_error) { /* use fallback */ }
  } else return nested;

  try { await picker.createDirectory?.("data", fallback, {}, { notify: false }); }
  catch (_error) { /* existing directory is expected */ }
  if (picker.browse) {
    try { await picker.browse("data", fallback, {}); return fallback; }
    catch (_error) { /* handled below */ }
  } else return fallback;
  throw new Error("Could not create a token-art upload folder in Foundry Data.");
}

function loadImage(source) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = "async";
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error(`Could not load token source image: ${source}`));
    image.src = source;
  });
}

function canvasBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("Token image rendering returned no image data.")), "image/png");
  });
}

/**
 * Render the selected portrait crop into a real circular PNG and upload it to Foundry Data.
 * offsetX/offsetY are normalized stage percentages, so preview movement and final rendering match.
 */
export async function createRoundTokenAsset(actor, {
  source = null,
  fit = "cover",
  zoom = 1,
  offsetX = 0,
  offsetY = 0
} = {}) {
  if (!actor) throw new Error("Actor is required to create a token image.");
  const src = String(source || actor.img || tokenTexture(actor)?.src || "");
  if (!src) throw new Error("No artwork is available for this token.");

  const picker = globalThis.FilePicker ?? foundry.applications?.apps?.FilePicker?.implementation;
  if (!picker?.upload) throw new Error("Foundry FilePicker upload API is unavailable in this client.");

  const image = await loadImage(src);
  const outputSize = 512;
  const canvas = document.createElement("canvas");
  canvas.width = outputSize;
  canvas.height = outputSize;
  const ctx = canvas.getContext("2d", { alpha: true });
  if (!ctx) throw new Error("Browser canvas is unavailable for Token Builder.");
  ctx.clearRect(0, 0, outputSize, outputSize);

  const radius = outputSize * 0.47;
  ctx.save();
  ctx.beginPath();
  ctx.arc(outputSize / 2, outputSize / 2, radius, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();

  const iw = Math.max(1, Number(image.naturalWidth || image.width || outputSize));
  const ih = Math.max(1, Number(image.naturalHeight || image.height || outputSize));
  const mode = String(fit) === "contain" ? "contain" : "cover";
  const ratio = mode === "contain"
    ? Math.min(outputSize / iw, outputSize / ih)
    : Math.max(outputSize / iw, outputSize / ih);
  const z = clamp(zoom, 0.25, 5);
  const drawW = iw * ratio * z;
  const drawH = ih * ratio * z;
  const shiftX = clamp(offsetX, -150, 150) / 100 * outputSize;
  const shiftY = clamp(offsetY, -150, 150) / 100 * outputSize;
  const dx = (outputSize - drawW) / 2 + shiftX;
  const dy = (outputSize - drawH) / 2 + shiftY;
  ctx.drawImage(image, dx, dy, drawW, drawH);
  ctx.restore();

  ctx.save();
  ctx.beginPath();
  ctx.arc(outputSize / 2, outputSize / 2, radius, 0, Math.PI * 2);
  ctx.lineWidth = 14;
  ctx.strokeStyle = "#d9bd79";
  ctx.stroke();
  ctx.restore();

  const blob = await canvasBlob(canvas);
  const directory = await ensureTokenArtDirectory(picker);
  const fileName = `${safeFilePart(actor.name)}-${safeFilePart(actor.id || "actor")}-${Date.now()}-token.png`;
  const file = new File([blob], fileName, { type: "image/png" });
  const response = await picker.upload("data", directory, file, {}, { notify: false });
  const path = response?.path ?? response?.paths?.[0];
  if (!path) throw new Error("Token upload did not return a usable path.");
  return path;
}

async function updateCurrentSceneTokens(actor, tokenPath, size) {
  const scene = canvas?.scene;
  if (!scene) return 0;
  const updates = (scene.tokens?.contents ?? [])
    .filter(token => String(token.actorId ?? "") === String(actor.id ?? ""))
    .map(token => ({
      _id: token.id,
      width: size,
      height: size,
      "texture.src": tokenPath,
      "texture.fit": "contain",
      "texture.anchorX": 0.5,
      "texture.anchorY": 0.5,
      "texture.scaleX": 1,
      "texture.scaleY": 1
    }));
  if (!updates.length) return 0;
  await scene.updateEmbeddedDocuments("Token", updates);
  return updates.length;
}

export async function openQuickTokenBuilder(actor) {
  if (!actor) return false;
  if (!actor.isOwner && !game.user?.isGM) return ui.notifications.warn("Realm Guard: You do not have permission to edit this Actor's prototype token.");

  // Always begin from the preserved source artwork when available. Once an NPC token is saved,
  // actor.img may intentionally become the round token portrait, so keep the original artwork in a flag.
  const texture = tokenTexture(actor);
  const preservedSource = actor.getFlag?.(NS, "tokenBuilderSourcePortrait");
  const source = String(preservedSource || actor.img || texture.src || "icons/svg/mystery-man.svg");
  const fit = "cover";
  const zoom = 1;
  const x = 0;
  const y = 0;
  const width = clamp(actor.prototypeToken?.width ?? 1, 0.5, 6);
  const height = clamp(actor.prototypeToken?.height ?? 1, 0.5, 6);

  const content = `<div class="rg-token-builder" data-rg-token-builder>
    <header><div class="rg-brand">REALM GUARD / TORCHBEARER</div><h2>Quick Token Builder</h2><p>Move the full portrait, zoom it and frame it inside the round guide. Nothing is saved until you choose <b>Create / Save Token</b>.</p></header>
    <div class="rg-token-builder-layout">
      <div class="rg-token-builder-stage" data-rg-token-stage title="Drag the full artwork to reposition it">
        <img src="${esc(source)}" alt="${esc(actor.name)} token preview" data-rg-token-image>
        <span class="rg-token-builder-ring" aria-hidden="true"></span>
      </div>
      <div class="rg-token-builder-controls">
        <input type="hidden" name="tokenSource" value="${esc(source)}" data-rg-token-source>
        <input type="hidden" name="offsetX" value="${x}" data-rg-token-x>
        <input type="hidden" name="offsetY" value="${y}" data-rg-token-y>
        <label>Zoom <input type="range" name="zoom" min="0.25" max="5" step="0.05" value="${zoom}" data-rg-token-zoom><output data-rg-token-zoom-label>${zoom.toFixed(2)}x</output></label>
        <label>Framing <select name="fit" data-rg-token-fit><option value="cover" selected>Fill / Crop</option><option value="contain">Fit Entire Image</option></select></label>
        <div class="rg-token-builder-actions"><button type="button" data-rg-token-center><i class="fa-solid fa-crosshairs"></i> Center</button><button type="button" data-rg-token-fit-button><i class="fa-solid fa-compress"></i> Fit</button><button type="button" data-rg-token-fill-button><i class="fa-solid fa-expand"></i> Fill</button></div>
        <label>Token Size <select name="size"><option value="1" ${width === 1 && height === 1 ? "selected" : ""}>1 × 1</option><option value="2" ${width === 2 && height === 2 ? "selected" : ""}>2 × 2</option><option value="3" ${width === 3 && height === 3 ? "selected" : ""}>3 × 3</option></select></label>
        <button type="button" class="rg-token-use-portrait" data-rg-token-use-portrait><i class="fa-solid fa-image"></i> Reset to Source Artwork</button>
        <label class="rg-token-update-scene"><span>Current Scene</span><span><input type="checkbox" name="updatePlaced" checked> Update placed tokens for this Actor</span></label>
        <small>Center, Fit, Fill, dragging and zoom only change the preview. Create / Save Token renders the current framing into a new round PNG and then updates the prototype token.</small>
      </div>
    </div>
  </div>`;

  const DialogV2 = foundry.applications.api.DialogV2;
  const dialog = new DialogV2({
    window: { title: `Realm Guard · Token Builder · ${actor.name}`, resizable: true },
    content,
    modal: false,
    buttons: [
      {
        action: "save",
        label: "Create / Save Token",
        icon: "fa-solid fa-floppy-disk",
        default: true,
        callback: async (_event, button) => {
          const form = button.form;
          if (!form) return false;
          try {
            const src = String(form.elements.tokenSource?.value || actor.img || source);
            const fitMode = String(form.elements.fit?.value || "cover");
            const zoomValue = clamp(form.elements.zoom?.value ?? 1, 0.25, 5);
            const ox = clamp(form.elements.offsetX?.value ?? 0, -150, 150);
            const oy = clamp(form.elements.offsetY?.value ?? 0, -150, 150);
            const size = clamp(form.elements.size?.value ?? 1, 0.5, 6);
            const tokenPath = await createRoundTokenAsset(actor, { source: src, fit: fitMode, zoom: zoomValue, offsetX: ox, offsetY: oy });
            const actorUpdate = {
              "flags.realm-guard.tokenBuilderSourcePortrait": src,
              "prototypeToken.name": actor.name,
              "prototypeToken.width": size,
              "prototypeToken.height": size,
              "prototypeToken.texture.src": tokenPath,
              "prototypeToken.texture.fit": "contain",
              "prototypeToken.texture.anchorX": 0.5,
              "prototypeToken.texture.anchorY": 0.5,
              "prototypeToken.texture.scaleX": 1,
              "prototypeToken.texture.scaleY": 1
            };
            // For NPCs, the deliberately framed round token also becomes the Actor portrait.
            // The original full artwork remains preserved above for future Token Builder edits.
            if (actor.type === "npc") actorUpdate.img = tokenPath;
            await actor.update(actorUpdate);
            const updatePlaced = Boolean(form.elements.updatePlaced?.checked);
            const updated = updatePlaced ? await updateCurrentSceneTokens(actor, tokenPath, size) : 0;
            ui.notifications.info(`Realm Guard: Token saved for ${actor.name}${updated ? ` and ${updated} Scene token${updated === 1 ? "" : "s"} updated` : ""}.`);
            return true;
          } catch (error) {
            console.error(`${NS} | Token Builder save failed`, error);
            ui.notifications.error(`Realm Guard: ${error.message || "Token Builder could not save the token."}`);
            return false;
          }
        }
      },
      { action: "cancel", label: "Cancel", callback: () => false }
    ]
  });

  await dialog.render(true);
  const root = dialog.element?.querySelector?.("[data-rg-token-builder]") ?? dialog.element;
  if (!root) return dialog;
  const stage = root.querySelector("[data-rg-token-stage]");
  const image = root.querySelector("[data-rg-token-image]");
  const xInput = root.querySelector("[data-rg-token-x]");
  const yInput = root.querySelector("[data-rg-token-y]");
  const zoomInput = root.querySelector("[data-rg-token-zoom]");
  const zoomLabel = root.querySelector("[data-rg-token-zoom-label]");
  const fitInput = root.querySelector("[data-rg-token-fit]");
  const sourceInput = root.querySelector("[data-rg-token-source]");

  const refresh = () => {
    if (!stage || !image) return;
    const stageW = Math.max(1, stage.clientWidth || 360);
    const stageH = Math.max(1, stage.clientHeight || stageW);
    const iw = Math.max(1, Number(image.naturalWidth || stageW));
    const ih = Math.max(1, Number(image.naturalHeight || stageH));
    const mode = String(fitInput?.value || "cover") === "contain" ? "contain" : "cover";
    const ratio = mode === "contain" ? Math.min(stageW / iw, stageH / ih) : Math.max(stageW / iw, stageH / ih);
    const z = clamp(zoomInput?.value ?? 1, 0.25, 5);
    const ox = clamp(xInput?.value ?? 0, -150, 150);
    const oy = clamp(yInput?.value ?? 0, -150, 150);
    image.style.width = `${iw * ratio * z}px`;
    image.style.height = `${ih * ratio * z}px`;
    image.style.left = `${stageW / 2 + stageW * ox / 100}px`;
    image.style.top = `${stageH / 2 + stageH * oy / 100}px`;
    image.style.transform = "translate(-50%, -50%)";
    if (zoomLabel) zoomLabel.textContent = `${z.toFixed(2)}x`;
  };

  let dragging = false;
  let startX = 0;
  let startY = 0;
  let originX = 0;
  let originY = 0;
  stage?.addEventListener("pointerdown", event => {
    if (event.button !== 0) return;
    dragging = true;
    startX = event.clientX;
    startY = event.clientY;
    originX = Number(xInput?.value ?? 0);
    originY = Number(yInput?.value ?? 0);
    stage.setPointerCapture?.(event.pointerId);
  });
  stage?.addEventListener("pointermove", event => {
    if (!dragging || !stage) return;
    const stageW = Math.max(1, stage.clientWidth || 360);
    const stageH = Math.max(1, stage.clientHeight || stageW);
    if (xInput) xInput.value = String(clamp(originX + ((event.clientX - startX) / stageW) * 100, -150, 150));
    if (yInput) yInput.value = String(clamp(originY + ((event.clientY - startY) / stageH) * 100, -150, 150));
    refresh();
  });
  const endDrag = event => { dragging = false; stage?.releasePointerCapture?.(event.pointerId); };
  stage?.addEventListener("pointerup", endDrag);
  stage?.addEventListener("pointercancel", endDrag);
  zoomInput?.addEventListener("input", refresh);
  fitInput?.addEventListener("change", refresh);
  image?.addEventListener("load", refresh);
  root.querySelector("[data-rg-token-center]")?.addEventListener("click", () => { if (xInput) xInput.value = "0"; if (yInput) yInput.value = "0"; refresh(); });
  root.querySelector("[data-rg-token-fit-button]")?.addEventListener("click", () => { if (fitInput) fitInput.value = "contain"; if (zoomInput) zoomInput.value = "1"; refresh(); });
  root.querySelector("[data-rg-token-fill-button]")?.addEventListener("click", () => { if (fitInput) fitInput.value = "cover"; if (zoomInput) zoomInput.value = "1"; refresh(); });
  root.querySelector("[data-rg-token-use-portrait]")?.addEventListener("click", () => {
    if (sourceInput) sourceInput.value = source;
    if (image) image.src = source;
    if (xInput) xInput.value = "0";
    if (yInput) yInput.value = "0";
    if (zoomInput) zoomInput.value = "1";
    if (fitInput) fitInput.value = "cover";
    refresh();
  });
  if (stage && globalThis.ResizeObserver) new ResizeObserver(() => refresh()).observe(stage);
  refresh();
  return dialog;
}
