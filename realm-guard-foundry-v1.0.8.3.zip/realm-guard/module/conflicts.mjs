import { diceFacesHtml } from "./dice-ui.mjs";
import { registerGmDockTool } from "./gm-dock.mjs";
import { tokenPowerOptionViews } from "./tokens-of-power.mjs";
import { talentOptionViews, resolveTalentUse, commitTalentUse, talentEffectSummary } from "./talents.mjs";
import { recordAbilityTest, recordHelperSkillTest } from "./advancement.mjs";
import { traitPositiveStatus } from "./traits.mjs";

const SYSTEM_ID = "realm-guard";
const PUBLIC_SETTING = "conflictState";
const PRIVATE_SETTING = "conflictPrivateState";
const SOCKET_CHANNEL = "system.realm-guard";
const WINDOW_ID = "rg-conflict-window";
const ACTIONS = ["attack", "defend", "feint", "maneuver"];
const ACTION_LABELS = { attack: "Attack", defend: "Defend", feint: "Feint", maneuver: "Maneuver" };
const ACTION_ICONS = {
  attack: "fa-solid fa-khanda",
  defend: "fa-solid fa-shield-halved",
  feint: "fa-solid fa-masks-theater",
  maneuver: "fa-solid fa-route"
};

const ACTION_GUIDE = {
  attack: {
    summary: "Direct pressure against the opponent's goal.",
    good: "Best for reducing enemy Disposition.",
    drawback: "Defend and Maneuver can oppose it."
  },
  defend: {
    summary: "Protect your position and recover lost ground.",
    good: "Best for preserving or restoring Disposition.",
    drawback: "Feint bypasses Defend."
  },
  feint: {
    summary: "Trick or misdirect the opposition.",
    good: "Best for exploiting an opponent who Defends.",
    drawback: "Attack trumps Feint."
  },
  maneuver: {
    summary: "Create a tactical opening instead of pressing directly.",
    good: "Best for Impede, Gain Position or Disarm effects.",
    drawback: "Often contests Attack or Defend before it pays off."
  }
};

export const CONFLICT_TYPES = {
  argument: { label: "Argument", disposition: { skills: ["Persuader"], base: "will" } },
  chase: { label: "Chase", disposition: { skills: ["Scout"], base: "health" } },
  fight: { label: "Fight", disposition: { skills: ["Fighter"], base: "health" } },
  fightCreature: { label: "Fight Creature", disposition: { skills: ["Hunter"], base: "health" } },
  journey: { label: "Journey", disposition: { skills: ["Pathfinder"], base: "health" } },
  negotiation: { label: "Negotiation", disposition: { skills: ["Haggler"], base: "will" } },
  speech: { label: "Speech", disposition: { skills: ["Orator"], base: "will" } },
  war: { label: "War", disposition: { skills: ["Militarist", "Lore Master"], base: "will" } },
  other: { label: "Other", disposition: { skills: [], base: "health" } }
};

// Realm Guard v1.6 takes precedence. Journey/War entries explicitly inherit the
// Mouse Guard descriptions for the cells where Realm Guard says "See MG".
export const CONFLICT_ACTION_SKILLS = {
  argument: {
    attack: ["Persuader"], defend: ["Persuader"],
    feint: ["Persuader", "Deceiver"], maneuver: ["Persuader", "Deceiver"]
  },
  chase: { attack: ["Scout"], defend: ["Pathfinder"], feint: ["Pathfinder"], maneuver: ["Scout"] },
  fight: { attack: ["Fighter"], defend: ["Fighter"], feint: ["Fighter"], maneuver: ["Fighter"] },
  fightCreature: {
    attack: ["Hunter", "Fighter"], defend: ["Hunter", "Animal Handler"],
    feint: ["Hunter"], maneuver: ["Animal Handler", "Lore Master"]
  },
  negotiation: { attack: ["Haggler"], defend: ["Haggler"], feint: ["Deceiver"], maneuver: ["Deceiver"] },
  journey: {
    attack: ["Pathfinder"], defend: ["Survivalist", "Weather Watcher"],
    feint: ["Pathfinder"], maneuver: ["Survivalist", "Weather Watcher"]
  },
  speech: { attack: ["Orator"], defend: ["Orator"], feint: ["Orator", "Deceiver"], maneuver: ["Orator", "Deceiver"] },
  war: {
    attack: ["Militarist", "Lore Master"], defend: ["Militarist", "Orator", "Administrator"],
    feint: ["Militarist", "Administrator"], maneuver: ["Militarist", "Lore Master"]
  },
  other: { attack: ["*"], defend: ["*"], feint: ["*"], maneuver: ["*"] }
};

export const ACTION_INTERACTION = {
  attack: { attack: "independent", defend: "versus", feint: "independent", maneuver: "versus" },
  defend: { attack: "versus", defend: "independent", feint: "trumped", maneuver: "versus" },
  feint: { attack: "trumped", defend: "independent", feint: "versus", maneuver: "independent" },
  maneuver: { attack: "versus", defend: "versus", feint: "independent", maneuver: "independent" }
};

const draftPlans = new Map();
const weaponDrafts = new Map();
const lockedPlanCache = new Map();
const CONFLICT_WEAPON_NAMES = new Set(["axe", "bow", "halberd", "whip", "hook and line", "knife", "shield", "sling", "spear", "staff", "sword"]);
let dismissedConflictId = null;
let dragOffset = null;

function esc(value) { return foundry.utils.escapeHTML(String(value ?? "")); }
function clone(value) { return foundry.utils.deepClone(value); }
function actionLabel(action) { return ACTION_LABELS[action] ?? action; }
function actorById(id) { return id ? game.actors.get(id) : null; }
function currentState() {
  try {
    const raw = game.settings.get(SYSTEM_ID, PUBLIC_SETTING);
    return raw ? JSON.parse(raw) : null;
  } catch (_err) { return null; }
}
function privateState() {
  try {
    const raw = game.settings.get(SYSTEM_ID, PRIVATE_SETTING);
    return raw ? JSON.parse(raw) : {};
  } catch (_err) { return {}; }
}
async function setPrivateState(value) {
  await game.settings.set(SYSTEM_ID, PRIVATE_SETTING, JSON.stringify(value ?? {}));
}
async function setPublicState(value) {
  if (!game.user?.isGM) throw new Error("Realm Guard: only the GM may write Conflict state.");
  await game.settings.set(SYSTEM_ID, PUBLIC_SETTING, value ? JSON.stringify(value) : "");
}
function isActive(state) { return Boolean(state?.active && state?.id); }
function isParticipantOwner(state) {
  if (!state || game.user?.isGM) return Boolean(game.user?.isGM);
  return (state.ranger?.participantIds ?? []).some(id => actorById(id)?.isOwner);
}
function canCaptainControl(state) {
  if (game.user?.isGM) return true;
  return Boolean(actorById(state?.ranger?.captainId)?.isOwner);
}
function canSideRoll(state, side) {
  if (side === "gm") return Boolean(game.user?.isGM);
  const pair = state?.revealed?.find(r => Number(r.index) === Number(state.currentIndex));
  const actor = actorById(pair?.rangerActorId);
  return Boolean(game.user?.isGM || actor?.isOwner);
}
function stageLabel(stage) {
  return ({
    disposition: "Starting Disposition", gmPlan: "GM Planning", rangerPlan: "Ranger Planning",
    ready: "Actions Locked", action: "Resolve Action", maneuver: "Maneuver Choice",
    compromise: "Compromise", complete: "Complete"
  })[stage] ?? String(stage ?? "Conflict");
}
function conflictTypeLabel(type) { return CONFLICT_TYPES[type]?.label ?? type; }
function conditionActive(actor, name) {
  const n = String(name).trim().toLowerCase();
  return actor?.items?.some(i => i.type === "condition" && i.system.active && String(i.name).trim().toLowerCase() === n);
}
function findRole(actor, names = []) {
  const wanted = names.map(n => String(n).toLowerCase());
  return actor?.items?.filter(i => i.type === "role" && wanted.includes(String(i.name).toLowerCase()))
    .sort((a, b) => Number(b.system.rating ?? 0) - Number(a.system.rating ?? 0))[0] ?? null;
}
function allTrainedRoles(actor) {
  return actor?.items?.filter(i => i.type === "role" && Number(i.system.rating ?? 0) > 0)
    .sort((a, b) => a.name.localeCompare(b.name)) ?? [];
}
function equippedGear(actor) {
  return actor?.items?.filter(i => i.type === "gear" && ["hand", "worn", "belt", "pocket", "slot"].includes(String(i.system.inventory?.mode ?? ""))) ?? [];
}
function normalizedGearName(item) { return String(item?.name ?? "").trim().toLowerCase(); }
function heldConflictWeapons(actor, state, side) {
  const disabled = new Set(state?.effects?.[side]?.disabledGearIds ?? []);
  return actor?.items?.filter(i => i.type === "gear" && String(i.system.inventory?.mode ?? "") === "hand" && !disabled.has(i.id) && CONFLICT_WEAPON_NAMES.has(normalizedGearName(i))) ?? [];
}
function selectedConflictWeapon(actor, state, side) {
  const weapons = heldConflictWeapons(actor, state, side);
  const selectedId = state?.weaponIds?.[actor?.id] ?? "";
  return weapons.find(i => i.id === selectedId) ?? (weapons.length === 1 ? weapons[0] : null);
}
function weaponDraftFor(actor, state, side) {
  const all = weaponDrafts.get(state.id) ?? {};
  const weapons = heldConflictWeapons(actor, state, side);
  const requested = all[actor.id] ?? state?.weaponIds?.[actor.id] ?? "";
  if (weapons.some(w => w.id === requested)) return requested;
  return weapons.length === 1 ? weapons[0].id : "";
}
function setWeaponDraft(state, actorId, weaponId) {
  const all = { ...(weaponDrafts.get(state.id) ?? {}) };
  all[actorId] = weaponId || "";
  weaponDrafts.set(state.id, all);
}
function validateWeaponId(actor, state, side, weaponId) {
  if (!weaponId) return "";
  return heldConflictWeapons(actor, state, side).some(w => w.id === weaponId) ? weaponId : "";
}
function enabledGear(actor, state, side) {
  const disabled = new Set(state?.effects?.[side]?.disabledGearIds ?? []);
  return equippedGear(actor).filter(item => !disabled.has(item.id));
}
function hasGearNamed(actor, state, side, names) {
  const wanted = new Set(names.map(n => String(n).toLowerCase()));
  return enabledGear(actor, state, side).some(i => wanted.has(normalizedGearName(i)));
}

export function interactionMode(ownAction, opponentAction, { ownMissile = false, opponentMissile = false } = {}) {
  if (ownAction === "attack" && opponentAction === "attack" && (ownMissile || opponentMissile)) return "versus";
  return ACTION_INTERACTION?.[ownAction]?.[opponentAction] ?? "independent";
}

export function validateRangerSequence(plan, participantIds, historicalCounts = {}, lastActorId = null) {
  if (!Array.isArray(plan) || plan.length !== 3) return { ok: false, reason: "Choose exactly three Ranger actions." };
  const team = [...new Set(participantIds ?? [])];
  if (!team.length) return { ok: false, reason: "The conflict needs at least one Ranger." };
  const counts = Object.fromEntries(team.map(id => [id, Math.max(0, Number(historicalCounts?.[id] ?? 0))]));
  let previous = lastActorId || null;
  for (let index = 0; index < plan.length; index += 1) {
    const actorId = plan[index]?.actorId;
    if (!team.includes(actorId)) return { ok: false, reason: `Action ${index + 1} must be assigned to a participating Ranger.` };
    if (team.length > 1 && actorId === previous) return { ok: false, reason: "A Ranger cannot take two actions in a row." };
    const currentCount = counts[actorId] ?? 0;
    const someoneStillBehind = team.some(id => (counts[id] ?? 0) < currentCount);
    if (someoneStillBehind) return { ok: false, reason: `${actorById(actorId)?.name ?? "That Ranger"} must wait until every patrol member has acted before taking another action.` };
    counts[actorId] = currentCount + 1;
    previous = actorId;
  }
  return { ok: true, counts, lastActorId: previous };
}

export function compromiseGrade(start, current) {
  const s = Math.max(0, Number(start ?? 0));
  const c = Math.max(0, Number(current ?? 0));
  if (!s || c >= s) return "none";
  const lost = s - c;
  if (lost * 2 < s) return "minor";
  if (lost * 2 === s) return "compromise";
  return "major";
}

function makeSideState() {
  return {
    disposition: { start: 0, current: 0, rolled: false, roll: null },
    nextDice: 0,
    disabledGearIds: [],
    swordAction: ""
  };
}

async function startConflictDialog() {
  if (!game.user?.isGM) return;
  const existing = currentState();
  if (isActive(existing)) {
    dismissedConflictId = null;
    renderConflictWindow(existing, { force: true });
    return;
  }

  const characters = game.actors.filter(a => a.type === "character").sort((a, b) => a.name.localeCompare(b.name));
  const opponents = game.actors.filter(a => ["character", "npc"].includes(a.type)).sort((a, b) => a.name.localeCompare(b.name));
  if (!characters.length || !opponents.length) return ui.notifications.warn("Realm Guard: Create at least one Ranger and one opponent Actor first.");

  const participantChecks = characters.map((a, i) => `<label class="rg-conflict-setup-ranger"><input type="checkbox" name="participant" value="${a.id}" ${i < Math.min(3, characters.length) ? "checked" : ""}> ${esc(a.name)}</label>`).join("");
  const captainOptions = characters.map(a => `<option value="${a.id}">${esc(a.name)}</option>`).join("");
  const opponentOptions = opponents.map(a => `<option value="${a.id}">${esc(a.name)} · ${a.type === "npc" ? "NPC" : "Character"}</option>`).join("");
  const typeOptions = Object.entries(CONFLICT_TYPES).map(([id, d]) => `<option value="${id}">${esc(d.label)}</option>`).join("");
  const content = `<div class="rg-conflict-setup">
    <p class="rg-conflict-callout"><b>Card Conflict Engine:</b> choose the conflict, teams and goals. Starting disposition is rolled in the shared Conflict Window.</p>
    <div class="rg-conflict-setup-grid">
      <label>Conflict name <input name="name" value="Realm Guard Conflict"></label>
      <label>Conflict type <select name="type">${typeOptions}</select></label>
      <label>Opponent <select name="opponentId">${opponentOptions}</select></label>
      <label>Conflict Captain <select name="captainId">${captainOptions}</select></label>
      <label>Other conflict base <select name="otherBaseKey"><option value="health">Health</option><option value="will">Will</option><option value="nature">Nature</option><option value="resources">Resources</option><option value="circles">Circles</option></select><small>Used only when Conflict Type is Other; Realm Guard leaves this to the GM.</small></label>
    </div>
    <fieldset><legend>Ranger team</legend><div class="rg-conflict-setup-rangers">${participantChecks}</div></fieldset>
    <label>Ranger Goal <textarea name="rangerGoal" rows="2" placeholder="What does the patrol want to accomplish?"></textarea></label>
    <label>GM / Opponent Goal <textarea name="gmGoal" rows="2" placeholder="What does the opposition want to accomplish?"></textarea></label>
    <p><small>Other conflicts use GM-assigned Skills in the roll dialog. Realm Guard conflict Skills are used automatically for standard conflict types.</small></p>
  </div>`;
  const result = await foundry.applications.api.DialogV2.wait({
    window: { title: "Realm Guard · Start Conflict" }, content, modal: false, rejectClose: false,
    buttons: [
      { action: "start", label: "Start Conflict", icon: "fa-solid fa-khanda", default: true, callback: (_e, b) => {
        const f = b.form?.elements;
        return {
          name: f?.name?.value?.trim() || "Realm Guard Conflict",
          type: f?.type?.value || "fight",
          opponentId: f?.opponentId?.value || "",
          captainId: f?.captainId?.value || "",
          otherBaseKey: f?.otherBaseKey?.value || "health",
          participantIds: [...(b.form?.querySelectorAll('input[name="participant"]:checked') ?? [])].map(el => el.value),
          rangerGoal: f?.rangerGoal?.value?.trim() || "",
          gmGoal: f?.gmGoal?.value?.trim() || ""
        };
      } },
      { action: "cancel", label: "Cancel", icon: "fa-solid fa-xmark", callback: () => null }
    ]
  });
  if (!result) return;
  if (!result.participantIds.length) return ui.notifications.warn("Realm Guard: Select at least one Ranger.");
  if (!result.participantIds.includes(result.captainId)) return ui.notifications.warn("Realm Guard: The Conflict Captain must be one of the participating Rangers.");
  if (!actorById(result.opponentId)) return ui.notifications.warn("Realm Guard: Choose an opponent Actor.");
  const id = foundry.utils.randomID();
  const state = {
    id, active: true, name: result.name, type: result.type, stage: "disposition", exchange: 1, currentIndex: 0,
    createdBy: game.user.id, createdAt: Date.now(), otherBaseKey: result.otherBaseKey || "health",
    ranger: { participantIds: result.participantIds, captainId: result.captainId, goal: result.rangerGoal, ...makeSideState() },
    gm: { actorId: result.opponentId, goal: result.gmGoal, ...makeSideState() },
    locks: { gm: false, ranger: false },
    revealed: [], rolls: { gm: null, ranger: null },
    effects: { ranger: { nextDice: 0, disabledGearIds: [], swordActions: {} }, gm: { nextDice: 0, disabledGearIds: [], swordActions: {} } },
    actionCounts: Object.fromEntries(result.participantIds.map(actorId => [actorId, 0])), lastRangerActorId: null,
    loreMasterActions: {}, weaponIds: {},
    outcome: null, compromise: null, log: []
  };
  await setPrivateState({ conflictId: id, gmPlan: [], rangerPlan: [] });
  lockedPlanCache.set(id, { gmPlan: [], rangerPlan: [] });
  dismissedConflictId = null;
  await setPublicState(state);
  renderConflictWindow(state, { force: true });
}

function conflictCard(action, side, { small = false, faceDown = false, selected = false, index = null } = {}) {
  const cls = [`rg-conflict-card`, `rg-${side}-card`, small ? "small" : "", faceDown ? "face-down" : "", selected ? "selected" : ""].filter(Boolean).join(" ");
  if (faceDown) return `<div class="${cls}" ${index !== null ? `data-slot-index="${index}"` : ""}><div class="rg-card-back-mark"><i class="${side === "gm" ? "fa-solid fa-eye" : "fa-solid fa-tree"}"></i></div><b>${side === "gm" ? "GM" : "RANGERS"}</b><span>Realm Guard / Torchbearer</span></div>`;
  return `<button type="button" class="${cls}" data-action-card="${esc(action)}" ${index !== null ? `data-slot-index="${index}"` : ""} title="${esc(actionLabel(action))}"><i class="${ACTION_ICONS[action]}"></i><b>${esc(actionLabel(action))}</b><span>${action === "attack" ? "Press the goal" : action === "defend" ? "Protect position" : action === "feint" ? "Exploit a weakness" : "Gain advantage"}</span></button>`;
}

function dispositionBar(side, data) {
  const start = Math.max(0, Number(data?.start ?? 0));
  const current = Math.max(0, Number(data?.current ?? 0));
  const pct = start ? Math.max(0, Math.min(100, Math.round((current / start) * 100))) : 0;
  return `<div class="rg-disposition rg-disposition-${side}"><div class="rg-disposition-head"><b>${side === "gm" ? "GM / Opposition" : "Rangers"}</b><strong>${data?.rolled ? `${current} / ${start}` : "Not rolled"}</strong></div><div class="rg-disposition-track"><span style="width:${pct}%"></span></div></div>`;
}

function planFor(side, state) {
  const draft = draftPlans.get(state.id)?.[side];
  if (Array.isArray(draft) && draft.length) return draft;
  const privateData = privateState();
  if (game.user?.isGM) return side === "gm" ? (privateData.gmPlan ?? []) : (privateData.rangerPlan ?? []);
  return [];
}
function setDraft(side, state, plan) {
  const d = draftPlans.get(state.id) ?? { gm: [], ranger: [] };
  d[side] = plan;
  draftPlans.set(state.id, d);
}
function planSlotHtml(side, state, index, planEntry, { editable = false } = {}) {
  const locked = Boolean(state.locks?.[side]);
  const revealed = state.revealed?.find(r => r.index === index);
  if (revealed) {
    const action = side === "gm" ? revealed.gmAction : revealed.rangerAction;
    const actorName = side === "ranger" ? actorById(revealed.rangerActorId)?.name : actorById(state.gm.actorId)?.name;
    return `<div class="rg-plan-slot revealed"><span class="rg-plan-no">${index + 1}</span>${conflictCard(action, side, { small: true })}<small>${esc(actorName ?? "")}</small></div>`;
  }
  if (locked) {
    const ownSideView = side === "gm" ? Boolean(game.user?.isGM) : Boolean(!game.user?.isGM && canCaptainControl(state));
    if (ownSideView && planEntry?.action) {
      const actorName = side === "ranger" ? actorById(planEntry.actorId)?.name : actorById(state.gm.actorId)?.name;
      return `<div class="rg-plan-slot locked own-plan"><span class="rg-plan-no">${index + 1}</span>${conflictCard(planEntry.action, side, { small: true })}<small>${esc(actorName ?? "Locked")}</small></div>`;
    }
    return `<div class="rg-plan-slot locked"><span class="rg-plan-no">${index + 1}</span>${conflictCard("attack", side, { small: true, faceDown: true })}<small>Locked</small></div>`;
  }
  if (!editable) return `<div class="rg-plan-slot waiting"><span class="rg-plan-no">${index + 1}</span>${conflictCard("attack", side, { small: true, faceDown: true })}<small>Waiting</small></div>`;
  const action = planEntry?.action;
  const actorSelect = side === "ranger" ? `<select class="rg-plan-actor" data-plan-actor="${index}">${(state.ranger.participantIds ?? []).map(id => `<option value="${id}" ${planEntry?.actorId === id ? "selected" : ""}>${esc(actorById(id)?.name ?? id)}</option>`).join("")}</select>` : `<small>${esc(actorById(state.gm.actorId)?.name ?? "GM")}</small>`;
  return `<div class="rg-plan-slot editable" data-plan-slot="${index}"><span class="rg-plan-no">${index + 1}</span>${action ? conflictCard(action, side, { small: true }) : `<button type="button" class="rg-empty-plan" data-clear-plan="${index}">Choose card</button>`}${actorSelect}<button type="button" class="rg-plan-clear" data-clear-plan="${index}" title="Clear"><i class="fa-solid fa-xmark"></i></button></div>`;
}

function weaponPlannerHtml(side, state, editable) {
  const actorIds = side === "gm" ? [state.gm.actorId] : (state.ranger.participantIds ?? []);
  const rows = actorIds.map(actorId => {
    const actor = actorById(actorId);
    if (!actor) return "";
    const weapons = heldConflictWeapons(actor, state, side);
    const selected = weaponDraftFor(actor, state, side);
    if (!weapons.length) return `<div class="rg-conflict-weapon-row"><b>${esc(actor.name)}</b><span>Natural / unarmed / no supported held weapon</span></div>`;
    if (!editable) {
      const item = weapons.find(w => w.id === (state.weaponIds?.[actorId] ?? selected));
      return `<div class="rg-conflict-weapon-row"><b>${esc(actor.name)}</b><span><i class="fa-solid fa-khanda"></i> ${esc(item?.name ?? "No weapon selected")}</span></div>`;
    }
    return `<label class="rg-conflict-weapon-row"><b>${esc(actor.name)}</b><select data-conflict-weapon-actor="${actorId}"><option value="">Natural / unarmed</option>${weapons.map(w => `<option value="${w.id}" ${selected === w.id ? "selected" : ""}>${esc(w.name)}</option>`).join("")}</select></label>`;
  }).join("");
  return `<div class="rg-conflict-weapons"><span class="rg-conflict-weapons-title">Conflict weapon · choose before locking action cards</span>${rows}</div>`;
}


function conflictActionGuideHtml() {
  return `<section class="rg-conflict-action-guide" aria-label="Conflict action guide">
    <div class="rg-conflict-action-guide-title"><i class="fa-solid fa-circle-info"></i><span>Conflict Action Guide</span><small>Choose the card that best fits what you want to achieve.</small></div>
    <div class="rg-conflict-action-guide-grid">${ACTIONS.map(action => {
      const guide = ACTION_GUIDE[action];
      return `<article class="rg-conflict-action-guide-item rg-guide-${esc(action)}"><header><i class="${ACTION_ICONS[action]}"></i><b>${esc(actionLabel(action))}</b></header><p>${esc(guide.summary)}</p><small><strong>Good for:</strong> ${esc(guide.good)} <strong>Watch out:</strong> ${esc(guide.drawback)}</small></article>`;
    }).join("")}</div>
  </section>`;
}

function cardPlannerHtml(side, state, editable) {
  const plan = planFor(side, state);
  return `<div class="rg-card-planner ${editable ? "editable" : "readonly"}">
    ${weaponPlannerHtml(side, state, editable)}
    ${editable ? `<div class="rg-card-deck"><span>Choose:</span>${ACTIONS.map(action => conflictCard(action, side, { small: true })).join("")}</div>` : ""}
    <div class="rg-plan-row">${[0,1,2].map(i => planSlotHtml(side, state, i, plan[i], { editable })).join("")}</div>
  </div>`;
}

function currentPair(state) { return state.revealed?.find(r => Number(r.index) === Number(state.currentIndex)) ?? null; }
function interactionBadge(mode) {
  const label = mode === "versus" ? "VERSUS" : mode === "trumped" ? "TRUMPED" : "INDEPENDENT";
  return `<span class="rg-interaction ${mode}">${label}</span>`;
}
function currentActionHtml(state) {
  const pair = currentPair(state);
  if (!pair) return "";
  const gmActor = actorById(state.gm.actorId);
  const rangerActor = actorById(pair.rangerActorId);
  const gmMode = pair.gmMode ?? interactionMode(pair.gmAction, pair.rangerAction, { ownMissile: sideHasMissile(gmActor, state, "gm"), opponentMissile: sideHasMissile(rangerActor, state, "ranger") });
  const rangerMode = pair.rangerMode ?? interactionMode(pair.rangerAction, pair.gmAction, { ownMissile: sideHasMissile(rangerActor, state, "ranger"), opponentMissile: sideHasMissile(gmActor, state, "gm") });
  const gmRoll = state.rolls?.gm;
  const rangerRoll = state.rolls?.ranger;
  const gmCan = canSideRoll(state, "gm") && gmMode !== "trumped" && !gmRoll && state.stage === "action";
  const rangerCan = canSideRoll(state, "ranger") && rangerMode !== "trumped" && !rangerRoll && state.stage === "action";
  const rollSummary = (roll, mode) => mode === "trumped" ? `<div class="rg-roll-state trumped">No test · action trumped</div>` : roll ? `<div class="rg-roll-state done"><b>${roll.successes}</b> successes <small>${esc(roll.skillName)} · ${diceFacesHtml(roll.faces ?? [])}${roll.tokenPowerName ? ` · Token: ${esc(roll.tokenPowerName)} L${Number(roll.tokenPowerLevel ?? 0)}` : ""}${roll.talentName ? ` · Talent: ${esc(roll.talentName)}${Number(roll.talentDice ?? 0) ? ` +${Number(roll.talentDice)}D` : ""}` : ""}</small></div>` : `<div class="rg-roll-state waiting">Waiting for roll</div>`;
  return `<section class="rg-current-action">
    <header><span>ACTION ${state.currentIndex + 1} · EXCHANGE ${state.exchange}</span><b>${interactionBadge(gmMode)} / ${interactionBadge(rangerMode)}</b></header>
    <div class="rg-action-versus-grid">
      <div class="rg-action-side gm"><h4>${esc(gmActor?.name ?? "Opposition")}</h4>${conflictCard(pair.gmAction, "gm")}${interactionBadge(gmMode)}${rollSummary(gmRoll, gmMode)}${gmCan ? `<button type="button" class="rg-conflict-primary" data-conflict-action="roll" data-side="gm"><i class="fa-solid fa-dice"></i> Roll GM Action</button>` : ""}</div>
      <div class="rg-action-clash"><i class="fa-solid fa-bolt"></i><b>VS</b><small>${gmMode === "versus" ? "Opposed test" : "Resolve by action rules"}</small></div>
      <div class="rg-action-side ranger"><h4>${esc(rangerActor?.name ?? "Ranger")}</h4>${conflictCard(pair.rangerAction, "ranger")}${interactionBadge(rangerMode)}${rollSummary(rangerRoll, rangerMode)}${rangerCan ? `<button type="button" class="rg-conflict-primary" data-conflict-action="roll" data-side="ranger"><i class="fa-solid fa-dice"></i> Roll Ranger Action</button>` : ""}</div>
    </div>
    ${pair.resultText ? `<div class="rg-action-result">${pair.resultText}${pair.tiePending && game.user?.isGM ? `<button type="button" class="rg-conflict-primary" data-conflict-action="resolve-tie"><i class="fa-solid fa-scale-balanced"></i> Resolve Versus Tie</button>` : ""}</div>` : ""}
  </section>`;
}

function maneuverHtml(state) {
  const pending = state.pendingManeuver;
  if (!pending || state.stage !== "maneuver") return "";
  const side = pending.side;
  const actor = side === "gm" ? actorById(state.gm.actorId) : actorById(currentPair(state)?.rangerActorId);
  const canChoose = side === "gm" ? game.user?.isGM : (game.user?.isGM || actor?.isOwner);
  if (!canChoose) return `<div class="rg-maneuver-panel"><b>${esc(actor?.name ?? side)} is choosing a Maneuver effect…</b></div>`;
  const points = Math.max(0, Number(pending.margin ?? 0));
  const choices = [];
  if (points >= 1) choices.push(`<button data-maneuver-choice="impede">Impede · opponent −1D next action</button>`);
  if (points >= 2) choices.push(`<button data-maneuver-choice="position">Gain Position · +2D next action</button>`);
  if (points >= 3) {
    choices.push(`<button data-maneuver-choice="disarm">Disarm · disable weapon / gear</button>`);
    choices.push(`<button data-maneuver-choice="combo">Impede + Gain Position</button>`);
  }
  return `<div class="rg-maneuver-panel"><h4>Maneuver · Margin ${points}</h4><p>Choose the effect for <b>${esc(actor?.name ?? side)}</b>.</p><div class="rg-maneuver-buttons">${choices.join("")}</div></div>`;
}

function compromiseHtml(state) {
  if (state.stage !== "compromise" && state.stage !== "complete") return "";
  const outcome = state.outcome ?? {};
  const winner = outcome.winner === "ranger" ? "Rangers" : outcome.winner === "gm" ? "GM / Opposition" : "Tie";
  const winnerSide = outcome.winner === "ranger" ? state.ranger : state.gm;
  const grade = outcome.winner === "tie" ? "dangerous tie" : compromiseGrade(winnerSide?.disposition?.start, winnerSide?.disposition?.current);
  const label = ({ none: "No Compromise", minor: "Minor Compromise", compromise: "Compromise", major: "Major Compromise", "dangerous tie": "Conflict Tie" })[grade] ?? grade;
  return `<section class="rg-compromise-panel"><h3>${esc(label)}</h3><p><b>${esc(winner)}</b> ${outcome.winner === "tie" ? "reached 0 disposition in the same action. Both goals are achieved; this is a dangerous outcome." : "won the conflict."}</p>
    ${outcome.winner !== "tie" ? `<p>Winner remaining disposition: <b>${winnerSide.disposition.current}/${winnerSide.disposition.start}</b>. The losing side proposes an appropriate “You win, but…” concession.</p>` : ""}
    ${state.compromise?.text ? `<div class="rg-compromise-text">${esc(state.compromise.text)}</div>` : ""}
    ${game.user?.isGM && state.stage === "compromise" ? `<label>Compromise / outcome notes<textarea id="rg-conflict-compromise-text" rows="3" placeholder="Record the agreed compromise…">${esc(state.compromise?.text ?? "")}</textarea></label><button type="button" class="rg-conflict-primary" data-conflict-action="finish"><i class="fa-solid fa-flag-checkered"></i> Finish Conflict</button>` : ""}
  </section>`;
}

function conflictGuidanceHtml(state) {
  const pair = currentPair(state);
  if (state.stage === "disposition") return `<section class="rg-conflict-guidance"><b>Step 1 · Starting Disposition</b><span>Roll once for each side. When both are ready, secret planning starts automatically.</span></section>`;
  if (state.stage === "gmPlan") return `<section class="rg-conflict-guidance"><b>Step 2 · GM plans secretly</b><span>GM chooses three action cards and locks them. Rangers do not see them.</span></section>`;
  if (state.stage === "rangerPlan") return `<section class="rg-conflict-guidance"><b>Step 3 · Rangers plan secretly</b><span>The Conflict Captain chooses three cards and assigns Rangers. Locking the plan reveals Action 1 automatically.</span></section>`;
  if (state.stage === "ready") return `<section class="rg-conflict-guidance"><b>Next action loading</b><span>No extra reveal click is normally needed.</span></section>`;
  if (state.stage === "action" && pair) {
    const waiting = []; if (!state.rolls?.gm && pair.gmMode !== "trumped") waiting.push("GM / Opposition"); if (!state.rolls?.ranger && pair.rangerMode !== "trumped") waiting.push("Ranger");
    const modeText = pair.gmMode === "versus" || pair.rangerMode === "versus" ? "Versus: both results oppose each other." : "Independent/trumped actions resolve by their Conflict interaction.";
    return `<section class="rg-conflict-guidance current"><b>Action ${state.currentIndex + 1} · ${esc(actionLabel(pair.gmAction))} vs ${esc(actionLabel(pair.rangerAction))}</b><span>${esc(modeText)} ${waiting.length ? `Waiting for: ${esc(waiting.join(" + "))}.` : "All required rolls are in; resolving automatically."}</span></section>`;
  }
  if (state.stage === "maneuver") return `<section class="rg-conflict-guidance current"><b>Maneuver result</b><span>Choose the earned Maneuver effect; the Conflict then continues automatically.</span></section>`;
  if (state.stage === "compromise") return `<section class="rg-conflict-guidance current"><b>Conflict resolved</b><span>Agree the final compromise/outcome and finish the Conflict.</span></section>`;
  return "";
}

function conflictHistoryHtml(state) {
  const rows = (state.log ?? []).slice(-16);
  if (!rows.length) return "";
  return `<details class="rg-conflict-history"><summary><i class="fa-solid fa-clock-rotate-left"></i> Exchange history</summary><ol>${rows.map(row => `<li>${esc(row)}</li>`).join("")}</ol></details>`;
}

function controlsHtml(state) {
  if (state.stage === "disposition") {
    const gmButton = !state.gm.disposition.rolled && game.user?.isGM ? `<button class="rg-conflict-primary" data-conflict-action="disposition" data-side="gm"><i class="fa-solid fa-dice"></i> Roll GM Disposition</button>` : "";
    const rangerButton = !state.ranger.disposition.rolled && canCaptainControl(state) ? `<button class="rg-conflict-primary" data-conflict-action="disposition" data-side="ranger"><i class="fa-solid fa-dice"></i> Roll Ranger Disposition</button>` : "";
    return `<div class="rg-conflict-controls">${gmButton}${rangerButton}<small>When both sides have disposition, the GM plans three secret cards first.</small></div>`;
  }
  if (state.stage === "gmPlan") {
    if (!game.user?.isGM) return `<div class="rg-conflict-controls waiting"><i class="fa-solid fa-lock"></i> GM is choosing three hidden action cards…</div>`;
    return `<div class="rg-conflict-controls"><button class="rg-conflict-primary gm" data-conflict-action="lock-plan" data-side="gm"><i class="fa-solid fa-lock"></i> Lock GM Cards</button></div>`;
  }
  if (state.stage === "rangerPlan") {
    if (!canCaptainControl(state)) return `<div class="rg-conflict-controls waiting"><i class="fa-solid fa-user-shield"></i> Conflict Captain is choosing and assigning three hidden cards…</div>`;
    return `<div class="rg-conflict-controls"><button class="rg-conflict-primary ranger" data-conflict-action="lock-plan" data-side="ranger"><i class="fa-solid fa-lock"></i> Lock Ranger Cards</button></div>`;
  }
  if (state.stage === "ready" && game.user?.isGM) return `<div class="rg-conflict-controls waiting"><i class="fa-solid fa-spinner fa-spin"></i> Plans locked · revealing Action ${state.currentIndex + 1} automatically… <button type="button" class="rg-conflict-retry" data-conflict-action="reveal" title="Use only if the automatic reveal did not complete">Retry reveal</button></div>`;
  if (state.stage === "ready") return `<div class="rg-conflict-controls waiting"><i class="fa-solid fa-lock"></i> Plans locked · Action ${state.currentIndex + 1} is revealing automatically.</div>`;
  return "";
}

function renderConflictWindow(state = currentState(), { force = false } = {}) {
  const old = document.getElementById(WINDOW_ID);
  if (!isActive(state) || !isParticipantOwner(state)) { old?.remove(); return; }
  if (!force && dismissedConflictId === state.id && !old) return;
  let root = old;
  if (!root) {
    root = document.createElement("section"); root.id = WINDOW_ID; root.className = "rg-conflict-window"; document.body.append(root);
  }
  root.dataset.stage = state.stage;
  const gmActor = actorById(state.gm.actorId);
  const captain = actorById(state.ranger.captainId);
  const gmEditable = state.stage === "gmPlan" && game.user?.isGM && !state.locks.gm;
  const rangerEditable = state.stage === "rangerPlan" && canCaptainControl(state) && !state.locks.ranger;
  root.innerHTML = `<header class="rg-conflict-titlebar" data-conflict-drag><div><span>REALM GUARD</span><h2>${esc(state.name)}</h2><small>${esc(conflictTypeLabel(state.type))} · ${esc(stageLabel(state.stage))} · Exchange ${state.exchange}</small></div><div class="rg-conflict-window-actions"><button type="button" data-conflict-action="close" title="Minimize / Restore Conflict Window"><i class="fa-solid fa-window-minimize"></i></button></div></header>
    <div class="rg-conflict-body">
      <div class="rg-conflict-goals"><article class="gm"><b>${esc(gmActor?.name ?? "Opposition")}</b><span>GM GOAL</span><p>${esc(state.gm.goal || "No goal entered")}</p></article><div class="rg-conflict-emblem"><i class="fa-solid fa-khanda"></i></div><article class="ranger"><b>Rangers · Captain ${esc(captain?.name ?? "—")}</b><span>RANGER GOAL</span><p>${esc(state.ranger.goal || "No goal entered")}</p></article></div>
      <div class="rg-disposition-grid">${dispositionBar("gm", state.gm.disposition)}${dispositionBar("ranger", state.ranger.disposition)}</div>
      ${conflictGuidanceHtml(state)}
      ${(state.stage === "gmPlan" || state.stage === "rangerPlan") ? conflictActionGuideHtml() : ""}
      <div class="rg-conflict-plans"><section class="rg-side-plan gm"><h3><i class="fa-solid fa-eye"></i> GM ACTION CARDS</h3>${cardPlannerHtml("gm", state, gmEditable)}</section><section class="rg-side-plan ranger"><h3><i class="fa-solid fa-tree"></i> RANGER ACTION CARDS</h3>${cardPlannerHtml("ranger", state, rangerEditable)}</section></div>
      ${controlsHtml(state)}${currentActionHtml(state)}${maneuverHtml(state)}${compromiseHtml(state)}${conflictHistoryHtml(state)}
      ${game.user?.isGM && state.stage !== "complete" ? `<div class="rg-conflict-admin"><button type="button" data-conflict-action="abort"><i class="fa-solid fa-ban"></i> Abort Conflict</button></div>` : ""}
    </div>`;
  bindWindowEvents(root, state);
}

function bindWindowEvents(root, state) {
  root.querySelector('[data-conflict-action="close"]')?.addEventListener("click", () => {
    root.classList.toggle("minimized");
    const icon = root.querySelector('[data-conflict-action="close"] i');
    if (icon) icon.className = root.classList.contains("minimized") ? "fa-solid fa-window-maximize" : "fa-solid fa-window-minimize";
  });
  root.querySelector('[data-conflict-action="abort"]')?.addEventListener("click", () => void abortConflict());
  root.querySelectorAll(".rg-card-deck [data-action-card]").forEach(button => button.addEventListener("click", () => {
    const side = state.stage === "gmPlan" && game.user?.isGM ? "gm" : state.stage === "rangerPlan" && canCaptainControl(state) ? "ranger" : null;
    if (!side) return;
    const plan = [...planFor(side, state)];
    const index = plan.findIndex(entry => !entry?.action);
    const slot = index >= 0 ? index : (plan.length < 3 ? plan.length : -1);
    if (slot < 0) return ui.notifications.warn("Realm Guard: Clear a plan slot before choosing another card.");
    plan[slot] = { action: button.dataset.actionCard, actorId: side === "ranger" ? (plan[slot]?.actorId || state.ranger.participantIds[slot % state.ranger.participantIds.length]) : state.gm.actorId };
    setDraft(side, state, plan);
    renderConflictWindow(state, { force: true });
  }));
  root.querySelectorAll("[data-clear-plan]").forEach(button => button.addEventListener("click", () => {
    const side = state.stage === "gmPlan" && game.user?.isGM ? "gm" : "ranger";
    const plan = [...planFor(side, state)];
    const index = Number(button.dataset.clearPlan); plan[index] = null; setDraft(side, state, plan); renderConflictWindow(state, { force: true });
  }));
  root.querySelectorAll("[data-plan-actor]").forEach(select => select.addEventListener("change", () => {
    const plan = [...planFor("ranger", state)]; const index = Number(select.dataset.planActor);
    plan[index] = { ...(plan[index] ?? {}), actorId: select.value }; setDraft("ranger", state, plan);
  }));
  root.querySelectorAll("[data-conflict-weapon-actor]").forEach(select => select.addEventListener("change", () => {
    setWeaponDraft(state, select.dataset.conflictWeaponActor, select.value);
  }));
  root.querySelectorAll("[data-conflict-action]").forEach(button => {
    const action = button.dataset.conflictAction;
    if (["close", "abort"].includes(action)) return;
    button.addEventListener("click", () => void handleWindowAction(action, button.dataset.side, state));
  });
  root.querySelectorAll("[data-maneuver-choice]").forEach(button => button.addEventListener("click", () => void chooseManeuver(button.dataset.maneuverChoice, state)));
  const header = root.querySelector("[data-conflict-drag]");
  header?.addEventListener("pointerdown", event => {
    if (event.target.closest("button")) return;
    const rect = root.getBoundingClientRect(); dragOffset = { x: event.clientX - rect.left, y: event.clientY - rect.top };
    header.setPointerCapture?.(event.pointerId);
  });
  header?.addEventListener("pointermove", event => {
    if (!dragOffset) return;
    root.style.left = `${Math.max(4, Math.min(window.innerWidth - root.offsetWidth - 4, event.clientX - dragOffset.x))}px`;
    root.style.top = `${Math.max(4, Math.min(window.innerHeight - 80, event.clientY - dragOffset.y))}px`;
    root.style.transform = "none";
  });
  header?.addEventListener("pointerup", () => { dragOffset = null; });
}

async function handleWindowAction(action, side, state) {
  if (action === "disposition") return rollDisposition(side, state);
  if (action === "lock-plan") return lockPlan(side, state);
  if (action === "reveal") return revealCurrentAction(state);
  if (action === "roll") return rollCurrentAction(side, state);
  if (action === "resolve-tie") return gmResolveCurrentPair(state);
  if (action === "finish") return finishConflict(state);
}

async function lockPlan(side, state) {
  const plan = planFor(side, state).filter(Boolean).slice(0, 3);
  if (plan.length !== 3 || plan.some(p => !ACTIONS.includes(p.action))) return ui.notifications.warn("Realm Guard: Choose all three action cards before locking.");
  if (side === "gm") {
    if (!game.user?.isGM || state.stage !== "gmPlan") return;
    const p = privateState(); p.conflictId = state.id; p.gmPlan = plan.map(x => ({ action: x.action })); await setPrivateState(p);
    lockedPlanCache.set(state.id, { ...(lockedPlanCache.get(state.id) ?? {}), gmPlan: clone(p.gmPlan) });
    const next = clone(state);
    const gmActor = actorById(state.gm.actorId);
    next.weaponIds = { ...(next.weaponIds ?? {}), [state.gm.actorId]: validateWeaponId(gmActor, state, "gm", weaponDraftFor(gmActor, state, "gm")) };
    next.locks.gm = true; next.stage = "rangerPlan"; next.log.push(`Exchange ${next.exchange}: GM cards locked.`); await setPublicState(next);
    return;
  }
  if (!canCaptainControl(state) || state.stage !== "rangerPlan") return;
  const validated = validateRangerSequence(plan, state.ranger.participantIds, state.actionCounts, state.lastRangerActorId);
  if (!validated.ok) return ui.notifications.warn(`Realm Guard: ${validated.reason}`);
  const rangerWeaponIds = Object.fromEntries((state.ranger.participantIds ?? []).map(actorId => {
    const actor = actorById(actorId);
    return [actorId, validateWeaponId(actor, state, "ranger", weaponDraftFor(actor, state, "ranger"))];
  }));
  if (game.user?.isGM) {
    const p = privateState(); p.conflictId = state.id; p.rangerPlan = plan; await setPrivateState(p);
    lockedPlanCache.set(state.id, { ...(lockedPlanCache.get(state.id) ?? {}), rangerPlan: clone(plan) });
    const next = clone(state); next.weaponIds = { ...(next.weaponIds ?? {}), ...rangerWeaponIds }; next.locks.ranger = true; next.stage = "ready"; next.pendingActionCounts = validated.counts; next.pendingLastRangerActorId = validated.lastActorId; next.log.push(`Exchange ${next.exchange}: Ranger cards locked.`); await setPublicState(next);
    await revealCurrentAction(next);
  } else {
    game.socket.emit(SOCKET_CHANNEL, { type: "conflict-intent", intent: "submitRangerPlan", conflictId: state.id, senderId: game.user.id, payload: { plan, weaponIds: rangerWeaponIds } });
    ui.notifications.info("Realm Guard: Ranger action cards sent to the GM and locked.");
  }
}

async function gmHandleRangerPlan(message, state) {
  const captain = actorById(state.ranger.captainId);
  const sender = game.users.get(message.senderId);
  if (!sender || !captain?.testUserPermission(sender, CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER)) return;
  if (state.stage !== "rangerPlan" || state.id !== message.conflictId) return;
  const plan = Array.isArray(message.payload?.plan) ? message.payload.plan.slice(0, 3) : [];
  if (plan.length !== 3 || plan.some(entry => !ACTIONS.includes(entry?.action))) return;
  const validated = validateRangerSequence(plan, state.ranger.participantIds, state.actionCounts, state.lastRangerActorId);
  if (!validated.ok) return;
  const p = privateState(); p.conflictId = state.id; p.rangerPlan = plan; await setPrivateState(p);
  lockedPlanCache.set(state.id, { ...(lockedPlanCache.get(state.id) ?? {}), rangerPlan: clone(plan) });
  const weaponIds = Object.fromEntries((state.ranger.participantIds ?? []).map(actorId => {
    const actor = actorById(actorId);
    return [actorId, validateWeaponId(actor, state, "ranger", message.payload?.weaponIds?.[actorId] ?? "")];
  }));
  const next = clone(state); next.weaponIds = { ...(next.weaponIds ?? {}), ...weaponIds }; next.locks.ranger = true; next.stage = "ready"; next.pendingActionCounts = validated.counts; next.pendingLastRangerActorId = validated.lastActorId; next.log.push(`Exchange ${next.exchange}: Ranger cards locked.`); await setPublicState(next);
  await revealCurrentAction(next);
}

function sideHasMissile(actor, state, side) {
  const weapon = selectedConflictWeapon(actor, state, side);
  return ["bow", "sling"].includes(normalizedGearName(weapon));
}
function gearActionModifiers(actor, action, state, side) {
  const weapon = selectedConflictWeapon(actor, state, side);
  const names = new Set(weapon ? [normalizedGearName(weapon)] : []);
  let dice = 0, conditionalSuccess = 0; const notes = [];
  if (names.has("shield") && action === "defend") { dice += 2; notes.push("Shield +2D Defend"); }
  if (names.has("halberd")) {
    if (["attack", "defend"].includes(action)) { dice += 1; notes.push("Halberd +1D"); }
    if (["feint", "maneuver"].includes(action)) { dice -= 1; notes.push("Halberd -1D"); }
  }
  if ((names.has("whip") || names.has("hook and line"))) {
    if (action === "maneuver") { dice += 1; conditionalSuccess += 1; notes.push("Whip +1D / +1s successful Maneuver"); }
    if (action === "attack") { dice -= 1; notes.push("Whip -1D Attack"); }
  }
  if (names.has("spear")) {
    if (action === "defend") { dice += 1; notes.push("Spear +1D Defend"); }
    if (action === "feint") { conditionalSuccess += 1; notes.push("Spear +1s successful Feint"); }
  }
  if (names.has("staff") && action === "feint") { dice += 1; notes.push("Staff +1D Feint"); }
  if (names.has("bow") && action === "maneuver") { dice += 2; notes.push("Bow +2D Maneuver"); }
  if (names.has("sling") && action === "maneuver") { dice += 1; notes.push("Sling +1D Maneuver"); }
  if (names.has("axe")) {
    if (action === "attack") { conditionalSuccess += 1; notes.push("Axe +1s successful Attack"); }
    if (["defend", "feint"].includes(action)) { dice -= 1; notes.push("Axe -1D"); }
  }
  const swordAction = String(state.effects?.[side]?.swordActions?.[actor?.id] ?? state.effects?.[side]?.swordAction ?? "");
  if (names.has("sword") && swordAction === action) { dice += 1; notes.push(`Sword Useful +1D ${actionLabel(action)}`); }
  return { dice, conditionalSuccess, notes, hasSword: names.has("sword"), swordAction };
}

function eligibleActionRoles(actor, state, side, action) {
  const lockedLoreAction = String(state?.loreMasterActions?.[actor?.id] ?? "");
  const roleAllowed = role => String(role?.name ?? "").toLowerCase() !== "lore master" || !lockedLoreAction || lockedLoreAction === action;
  let choices = [];
  // Realm Guard creature/NPC examples sometimes substitute Nature or a creature-specific trained
  // Skill for an action. Give the GM that adjudication space instead of forcing one generic pool.
  if (side === "gm" && state.type === "fightCreature" && actor?.type === "npc") {
    choices = allTrainedRoles(actor).filter(roleAllowed).map(r => ({ id: r.id, name: r.name, rating: Number(r.system.rating ?? 0), kind: "role" }));
  } else {
    const names = CONFLICT_ACTION_SKILLS[state.type]?.[action] ?? ["*"];
    if (names.includes("*")) choices = allTrainedRoles(actor).filter(roleAllowed).map(r => ({ id: r.id, name: r.name, rating: Number(r.system.rating ?? 0), kind: "role" }));
    else {
      const lower = new Set(names.map(n => n.toLowerCase()));
      choices = actor.items.filter(i => i.type === "role" && lower.has(String(i.name).toLowerCase()) && roleAllowed(i)).map(r => ({ id: r.id, name: r.name, rating: Number(r.system.rating ?? 0), kind: "role" }));
    }
  }
  // Realm Guard permits Dunadan Nature to stand in for a typical ability when a descriptor
  // genuinely fits the fiction. The table/GM must validate the descriptor; this is not an
  // Acting Against Nature shortcut.
  const nature = Number(actor?.system?.attributes?.nature?.value ?? 0);
  if (nature > 0) choices.push({ id: "@nature", name: "Nature", label: "Nature (descriptor applies)", rating: nature, kind: "ability" });
  return choices;
}

async function openPoolDialog({ actor, title, choices, temporaryDice = 0, gear = null, participants = [], side = "ranger", allowSwordChoice = false, state = null, action = "", maxHelpers = null }) {
  if (!choices.length) return ui.notifications.warn(`Realm Guard: ${actor.name} has no eligible trained Skill for this conflict action.`);
  const roleOptions = choices.map(c => `<option value="${c.id}">${esc(c.label ?? c.name)} · ${c.rating}D</option>`).join("");
  const traitOptions = actor.traits?.map(t => { const status = traitPositiveStatus(actor, t); const level = Number(t.system.rating ?? 0); const state = level === 3 ? "+1s · always" : status.available ? `+1D · ${status.remaining}/${status.limit} left` : "+1D · USED"; return `<option value="${t.id}">${esc(t.name)} · L${level} · ${state}</option>`; }).join("") ?? "";
  const wiseOptions = actor.wises?.map(w => `<option value="${w.id}">${esc(w.name)}</option>`).join("") ?? "";
  const tokenById = new Map();
  for (const choice of choices) {
    const choiceIsSkill = choice.id !== "@nature" && choice.kind !== "ability";
    for (const token of tokenPowerOptionViews(actor, choice.name, { isSkill: choiceIsSkill })) {
      if (!tokenById.has(token.id)) tokenById.set(token.id, token);
    }
  }
  const tokenOptions = [...tokenById.values()].sort((a, b) => a.name.localeCompare(b.name));
  const tokenBlock = tokenOptions.length ? `<label>Token of Power <select name="tokenPowerId"><option value="">None</option>${tokenOptions.map(t => `<option value="${t.id}" ${t.disabled ? "disabled" : ""}>${esc(t.label)}</option>`).join("")}</select></label><small class="rg-token-conflict-note"><i class="fa-solid fa-gem"></i> Skill-linked Tokens must match the Skill/Ability selected above. Specific-use Tokens require table approval. Manual-effect Tokens are recorded but need Modifier/Extra Dice or table adjudication. An appropriate Token may also affect Scale of Might; v0.22 leaves the exact rank ruling to the GM/table.</small>` : "";
  const talentById = new Map();
  for (const choice of choices) {
    const choiceIsSkill = choice.id !== "@nature" && choice.kind !== "ability";
    for (const talent of talentOptionViews(actor, choice.name, { isSkill: choiceIsSkill, contextKey: state?.id ?? "" })) {
      if (!talentById.has(talent.id)) talentById.set(talent.id, talent);
    }
  }
  const talentOptions = [...talentById.values()].sort((a, b) => a.name.localeCompare(b.name));
  const talentBlock = talentOptions.length ? `<label>Talent <select name="talentId"><option value="">None</option>${talentOptions.map(t => `<option value="${t.id}" ${t.disabled ? "disabled" : ""}>${esc(t.label)}</option>`).join("")}</select></label><small class="rg-talent-conflict-note"><i class="fa-solid fa-sparkles"></i> Talents must match the selected Skill/Ability. Once/session or once/conflict uses are committed only when the roll is made.</small>` : "";
  const helperBlocks = side === "ranger" ? participants.filter(id => id !== actor.id).map(id => {
    const h = actorById(id); if (!h || conditionActive(h, "Afraid")) return "";
    return `<label class="rg-conflict-helper"><input type="checkbox" name="helper" value="${id}"> ${esc(h.name)} +1D Help</label>`;
  }).join("") : "";
  const sword = allowSwordChoice && gear?.hasSword && !gear.swordAction ? `<label><input type="checkbox" name="lockSword"> Use Sword's +1D on ${esc(actionLabel(action))} for the rest of this fight</label>` : "";
  const content = `<div class="rg-conflict-roll-dialog"><h3>${esc(title)}</h3>
    <label>Skill / Ability <select name="source">${roleOptions}</select></label>
    <div class="rg-roll-dialog-grid"><label>Modifier <input type="number" name="modifier" value="0"></label><label>Extra Dice <input type="number" name="extra" min="0" value="0"></label></div>
    ${temporaryDice ? `<p class="rg-conflict-tactical"><b>Tactical modifier:</b> ${temporaryDice > 0 ? "+" : ""}${temporaryDice}D from Maneuver.</p>` : ""}
    ${gear?.notes?.length ? `<p class="rg-conflict-gear"><b>Gear:</b> ${gear.notes.map(esc).join(" · ")}</p>` : ""}
    ${choices.some(c => c.id === "@nature") ? `<p class="rg-conflict-nature"><b>Nature:</b> choose it only when a Dunadan Nature descriptor genuinely applies to this action; do not use it as a generic substitute.</p>` : ""}
    ${sword}
    ${helperBlocks ? `<fieldset><legend>Teamwork</legend>${helperBlocks}${Number.isFinite(maxHelpers) ? `<small>Up to ${maxHelpers} patrol-mates may help this action.</small>` : ""}</fieldset>` : ""}
    <fieldset><legend>Resources / Character</legend><label>Persona dice <select name="persona" ${Number(actor.system.resources?.persona?.value ?? 0) < 1 ? "disabled" : ""}>${[0,1,2,3].filter(n => n <= Number(actor.system.resources?.persona?.value ?? 0)).map(n => `<option value="${n}">${n} Persona · +${n}D</option>`).join("") || `<option value="0">0 Persona · +0D</option>`}</select></label><label>Trait <select name="traitId"><option value="">None</option>${traitOptions}</select></label><small>Trait benefits use the same session limits as normal rolls: L1 +1D once, L2 +1D twice, L3 +1s when relevant.</small><label>Wise <select name="wiseId"><option value="">None</option>${wiseOptions}</select></label>${tokenBlock}${talentBlock}</fieldset>
    <small>Fate is offered after the roll when a 6 is present. Conflict rolls do not spend Players' Turn Free Tests/Checks.</small>
  </div>`;
  return await foundry.applications.api.DialogV2.wait({
    window: { title: `Realm Guard · ${title}` }, content, modal: false, rejectClose: false,
    buttons: [
      { action: "roll", label: "Roll", icon: "fa-solid fa-dice", default: true, callback: (_e, b) => ({
        sourceId: b.form?.elements?.source?.value || choices[0].id,
        modifier: Number(b.form?.elements?.modifier?.value ?? 0), extra: Math.max(0, Number(b.form?.elements?.extra?.value ?? 0)),
        persona: Math.max(0, Math.min(3, Number(b.form?.elements?.persona?.value ?? 0))), traitId: b.form?.elements?.traitId?.value || null, wiseId: b.form?.elements?.wiseId?.value || null, tokenPowerId: b.form?.elements?.tokenPowerId?.value || null, talentId: b.form?.elements?.talentId?.value || null,
        helperIds: (() => { const ids = [...(b.form?.querySelectorAll('input[name="helper"]:checked') ?? [])].map(el => el.value); return Number.isFinite(maxHelpers) ? ids.slice(0, maxHelpers) : ids; })(), lockSword: Boolean(b.form?.elements?.lockSword?.checked)
      }) },
      { action: "cancel", label: "Cancel", icon: "fa-solid fa-xmark", callback: () => null }
    ]
  });
}

async function executeActorPool({ actor, source, modifier = 0, extra = 0, persona = 0, traitId = null, wiseId = null, tokenPowerId = null, talentId = null, helperIds = [], temporaryDice = 0, gear = { dice: 0, conditionalSuccess: 0, notes: [] }, label = "Conflict", contextKey = "" }) {
  const personaDice = Math.max(0, Math.min(3, Math.trunc(Number(persona ?? 0))));
  const isNature = source.id === "@nature" || source.kind === "ability";
  const base = source.id === "@nature" ? Number(actor.system.attributes?.nature?.value ?? 0) : (source.kind === "ability" ? Number(source.rating ?? actor.system.attributes?.[source.key]?.value ?? 0) : Number(actor.items.get(source.id)?.system.rating ?? source.rating ?? 0));
  const power = actor._tokenPowerUse?.(tokenPowerId, source.name, { isSkill: !isNature }) ?? null;
  if (tokenPowerId && !power) return ui.notifications.warn("Realm Guard: That Token of Power is spent, unavailable, or does not match the selected conflict Skill/use.");
  const talentUse = resolveTalentUse(actor, talentId, source.name, { isSkill: !isNature, contextKey });
  if (talentId && !talentUse) return ui.notifications.warn("Realm Guard: That Talent is used, unavailable, or does not match the selected conflict Skill/Ability.");
  const conditionData = actor._activeConditionRollData?.(source.name, { isSkill: !isNature }) ?? { dice: 0, active: [] };
  const assist = actor._rollAssist?.({ traitId, wiseId, traitMode: "help", versus: false }) ?? { traitDice: 0, trait: null, wise: null };
  const helpDice = helperIds.length;
  const pool = Math.max(0, base + Number(modifier) + Number(extra) + Number(temporaryDice) + Number(gear.dice ?? 0) + Number(conditionData.dice ?? 0) + Number(assist.traitDice ?? 0) + Number(power?.diceBonus ?? 0) + Number(talentUse?.diceBonus ?? 0) + helpDice + personaDice);
  if (pool < 1) return ui.notifications.warn("Realm Guard: Conflict dice pool is 0.");
  if (personaDice) {
    const current = Number(actor.system.resources?.persona?.value ?? 0); if (current < personaDice) return ui.notifications.warn(`Realm Guard: This conflict roll requires ${personaDice} Persona.`);
    const spent = await actor.spendTrackedResource?.("persona", personaDice, { reason: `${label} conflict roll` });
    if (spent && !spent.ok) return ui.notifications.warn(`Realm Guard: ${spent.reason}`);
  }
  const roll = await new Roll(`${pool}d6`).evaluate();
  await actor._commitTraitBenefit?.(assist);
  await actor._commitTokenPowerUse?.(power);
  if (talentUse?.talent) await commitTalentUse(talentUse);
  let baseFaces = roll.dice.flatMap(d => d.results.map(r => r.result));
  const wise = assist.wise ?? (wiseId ? actor.items.get(wiseId) : null);
  const wiseResult = actor._applyWiseReroll ? await actor._applyWiseReroll(baseFaces, wise) : { faces: baseFaces, rerollFaces: [], rerolledIndexes: [] };
  baseFaces = wiseResult.faces;
  const tokenResult = actor._applyTokenPowerReroll ? await actor._applyTokenPowerReroll(baseFaces, power, wiseResult.rerolledIndexes ?? []) : { faces: baseFaces, rerollFaces: [], rerolledIndexes: [] };
  baseFaces = tokenResult.faces;
  const sixes = baseFaces.filter(v => v === 6).length;
  let fateFaces = [], fateSpent = false;
  if (sixes > 0 && Number(actor.system.resources?.fate?.value ?? 0) > 0 && actor._askFateAfterSixes) {
    fateSpent = await actor._askFateAfterSixes({ roleName: `${label} · ${source.name}`, sixCount: sixes });
    if (fateSpent) {
      fateFaces = await actor._explodeSixes(baseFaces);
      await actor.spendTrackedResource?.("fate", 1, { reason: `${label} conflict Fate` });
    }
  }
  const faces = baseFaces.concat(fateFaces);
  return {
    actorId: actor.id, sourceId: source.id, roleId: isNature ? null : source.id, abilityKey: isNature ? (source.key ?? "nature") : null, skillName: source.name, base, pool, faces,
    rerollFaces: wiseResult.rerollFaces ?? [], tokenPowerRerollFaces: tokenResult.rerollFaces ?? [], fateFaces, fateSpent, personaSpent: personaDice,
    successes: faces.filter(v => v >= 4).length, conditionalSuccess: Math.max(0, Number(gear.conditionalSuccess ?? 0)), traitSuccessLevel3: Number(assist?.traitStatus?.level ?? 0) === 3 && assist?.traitMode === "help", traitName: assist?.trait?.name ?? "",
    tokenPowerId: power?.token?.id ?? null, tokenPowerName: power?.token?.name ?? "", tokenPowerLevel: power?.level ?? 0, tokenPowerManual: Boolean(power?.manual), tokenPowerLink: power?.linkSummary ?? "",
    talentId: talentUse?.talent?.id ?? null, talentName: talentUse?.talent?.name ?? "", talentDice: Number(talentUse?.diceBonus ?? 0), talentManual: Boolean(talentUse?.manual), talentEffect: talentUse?.talent ? talentEffectSummary(talentUse.talent) : "",
    helperIds, modifier: Number(modifier), extra: Number(extra), temporaryDice: Number(temporaryDice), gearDice: Number(gear.dice ?? 0), gearNotes: gear.notes ?? []
  };
}

async function rollDisposition(side, state) {
  if (state.stage !== "disposition") return;
  if (side === "gm" && !game.user?.isGM) return;
  if (side === "ranger" && !canCaptainControl(state)) return;
  const actor = side === "gm" ? actorById(state.gm.actorId) : actorById(state.ranger.captainId);
  if (!actor) return;
  let choices = [];
  let baseKey = state.type === "other" ? (state.otherBaseKey || "health") : (CONFLICT_TYPES[state.type]?.disposition?.base ?? "health");
  if (side === "gm" && state.type === "fightCreature" && actor.type === "npc" && Number(actor.system.attributes?.nature?.value ?? 0) > 0) {
    choices = [{ id: "@nature", name: "Nature", rating: Number(actor.system.attributes.nature.value ?? 0), kind: "ability" }]; baseKey = "nature";
  } else {
    const names = CONFLICT_TYPES[state.type]?.disposition?.skills ?? [];
    if (state.type === "other") choices = allTrainedRoles(actor).map(r => ({ id: r.id, name: r.name, rating: Number(r.system.rating ?? 0), kind: "role" }));
    else choices = actor.items.filter(i => i.type === "role" && names.map(n => n.toLowerCase()).includes(String(i.name).toLowerCase())).map(r => ({ id: r.id, name: r.name, rating: Number(r.system.rating ?? 0), kind: "role" }));
  }
  const baseValue = Number(actor.system.attributes?.[baseKey]?.value ?? 0);
  const dialog = await openPoolDialog({ actor, title: `${side === "gm" ? "GM" : "Ranger"} Starting Disposition`, choices, participants: side === "ranger" ? state.ranger.participantIds : [], side, state });
  if (!dialog) return;
  const source = choices.find(c => c.id === dialog.sourceId) ?? choices[0];
  const roll = await executeActorPool({ actor, source, modifier: dialog.modifier, extra: dialog.extra, persona: dialog.persona, traitId: dialog.traitId, wiseId: dialog.wiseId, tokenPowerId: dialog.tokenPowerId, talentId: dialog.talentId, helperIds: dialog.helperIds, label: "Starting Disposition", contextKey: state.id });
  if (!roll) return;
  const penalty = (conditionActive(actor, "Tired") ? 1 : 0) + (baseKey === "will" && conditionActive(actor, "Angry") ? 1 : 0);
  const disposition = Math.max(0, baseValue + roll.successes - penalty);
  const payload = { side, disposition, baseKey, baseValue, penalty, roll };
  if (game.user?.isGM) await gmApplyDisposition(payload, state);
  else game.socket.emit(SOCKET_CHANNEL, { type: "conflict-intent", intent: "submitDisposition", conflictId: state.id, senderId: game.user.id, payload });
}

async function gmApplyDisposition(payload, state = currentState()) {
  if (!game.user?.isGM || !state || state.stage !== "disposition") return;
  const side = payload.side; if (!['gm','ranger'].includes(side)) return;
  const next = clone(state); const d = Math.max(0, Number(payload.disposition ?? 0));
  next[side].disposition = { start: d, current: d, rolled: true, roll: payload.roll, baseKey: payload.baseKey, baseValue: payload.baseValue, penalty: payload.penalty };
  next.log.push(`${side === "gm" ? "GM" : "Rangers"} starting disposition: ${d}.`);
  if (next.gm.disposition.rolled && next.ranger.disposition.rolled) next.stage = "gmPlan";
  await setPublicState(next);
}

async function revealCurrentAction(state) {
  if (!game.user?.isGM || state.stage !== "ready") return;
  const p = privateState();
  const cached = lockedPlanCache.get(state.id) ?? {};
  const gmPlan = Array.isArray(p.gmPlan) && p.gmPlan.length === 3 ? p.gmPlan : cached.gmPlan;
  const rangerPlan = Array.isArray(p.rangerPlan) && p.rangerPlan.length === 3 ? p.rangerPlan : cached.rangerPlan;
  const gmEntry = gmPlan?.[state.currentIndex]; const rangerEntry = rangerPlan?.[state.currentIndex];
  if (!gmEntry?.action || !rangerEntry?.action) {
    ui.notifications.error("Realm Guard: Hidden Conflict plan data could not be recovered. The exchange was safely returned to planning instead of getting stuck.");
    const reset = clone(state); reset.stage = "gmPlan"; reset.currentIndex = 0; reset.locks = { gm: false, ranger: false }; reset.revealed = []; reset.rolls = { gm: null, ranger: null }; reset.log.push(`Exchange ${reset.exchange}: hidden plan recovery failed; planning reset.`);
    await setPrivateState({ conflictId: state.id, gmPlan: [], rangerPlan: [] }); lockedPlanCache.set(state.id, { gmPlan: [], rangerPlan: [] }); await setPublicState(reset);
    return;
  }
  const gmActor = actorById(state.gm.actorId); const rangerActor = actorById(rangerEntry.actorId);
  const gmMode = interactionMode(gmEntry.action, rangerEntry.action, { ownMissile: sideHasMissile(gmActor, state, "gm"), opponentMissile: sideHasMissile(rangerActor, state, "ranger") });
  const rangerMode = interactionMode(rangerEntry.action, gmEntry.action, { ownMissile: sideHasMissile(rangerActor, state, "ranger"), opponentMissile: sideHasMissile(gmActor, state, "gm") });
  const next = clone(state);
  next.revealed = [...(next.revealed ?? []).filter(r => r.index !== next.currentIndex), { index: next.currentIndex, gmAction: gmEntry.action, rangerAction: rangerEntry.action, rangerActorId: rangerEntry.actorId, gmMode, rangerMode, resultText: "" }];
  next.rolls = { gm: gmMode === "trumped" ? { trumped: true, successes: 0 } : null, ranger: rangerMode === "trumped" ? { trumped: true, successes: 0 } : null };
  next.stage = "action";
  next.log.push(`Action ${next.currentIndex + 1}: ${actionLabel(gmEntry.action)} vs ${actionLabel(rangerEntry.action)}.`);
  await setPublicState(next);
  // If both actions are trumped (should not occur in the legal matrix), resolve defensively.
  if (next.rolls.gm?.trumped && next.rolls.ranger?.trumped) await gmResolveCurrentPair(next);
}

async function rollCurrentAction(side, state) {
  const pair = currentPair(state); if (!pair || state.stage !== "action" || !canSideRoll(state, side)) return;
  const actor = side === "gm" ? actorById(state.gm.actorId) : actorById(pair.rangerActorId); if (!actor) return;
  const action = side === "gm" ? pair.gmAction : pair.rangerAction;
  const mode = side === "gm" ? pair.gmMode : pair.rangerMode; if (mode === "trumped") return;
  const choices = eligibleActionRoles(actor, state, side, action);
  const tactical = Number(state.effects?.[side]?.nextDice ?? 0);
  const gear = ["fight", "fightCreature"].includes(state.type) ? gearActionModifiers(actor, action, state, side) : { dice: 0, conditionalSuccess: 0, notes: [], hasSword: false, swordAction: "" };
  const dialog = await openPoolDialog({ actor, title: `${actionLabel(action)} · ${mode === "versus" ? "Versus" : "Independent"}`, choices, temporaryDice: tactical, gear, participants: side === "ranger" ? state.ranger.participantIds : [], side, allowSwordChoice: ["fight", "fightCreature"].includes(state.type), state, action, maxHelpers: side === "ranger" ? 2 : null });
  if (!dialog) return;
  if (dialog.lockSword && gear.hasSword && !gear.swordAction) gear.dice += 1;
  const source = choices.find(c => c.id === dialog.sourceId) ?? choices[0];
  const roll = await executeActorPool({ actor, source, modifier: dialog.modifier, extra: dialog.extra, persona: dialog.persona, traitId: dialog.traitId, wiseId: dialog.wiseId, tokenPowerId: dialog.tokenPowerId, talentId: dialog.talentId, helperIds: dialog.helperIds, temporaryDice: tactical, gear, label: actionLabel(action), contextKey: state.id });
  if (!roll) return;
  roll.lockSwordAction = dialog.lockSword ? action : "";
  const message = { side, roll };
  if (game.user?.isGM) await gmApplyActionRoll(message, state);
  else game.socket.emit(SOCKET_CHANNEL, { type: "conflict-intent", intent: "submitActionRoll", conflictId: state.id, senderId: game.user.id, payload: message });
}

async function gmApplyActionRoll(payload, state = currentState(), sender = null) {
  if (!game.user?.isGM || !state || state.stage !== "action") return;
  const side = payload.side; if (!['gm','ranger'].includes(side) || state.rolls?.[side]) return;
  const pair = currentPair(state); if (!pair) return;
  if (side === "ranger" && sender) {
    const actor = actorById(pair.rangerActorId); if (!actor?.testUserPermission(sender, CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER)) return;
  }
  const next = clone(state);
  if (String(payload.roll?.skillName ?? "").toLowerCase() === "lore master") {
    const actorId = payload.roll?.actorId;
    const action = side === "gm" ? pair.gmAction : pair.rangerAction;
    const locked = String(next.loreMasterActions?.[actorId] ?? "");
    if (locked && locked !== action) return ui.notifications.warn(`Realm Guard: Lore Master is already assigned to ${actionLabel(locked)} in this conflict.`);
    next.loreMasterActions = { ...(next.loreMasterActions ?? {}), [actorId]: action };
  }
  next.rolls[side] = payload.roll;
  if (payload.roll?.lockSwordAction) {
    const actorId = payload.roll?.actorId;
    next.effects[side].swordActions = { ...(next.effects[side].swordActions ?? {}) };
    if (actorId && !next.effects[side].swordActions[actorId]) next.effects[side].swordActions[actorId] = payload.roll.lockSwordAction;
  }
  // Tactical Maneuver bonuses/penalties are consumed by the next actual test.
  next.effects[side].nextDice = 0;
  await setPublicState(next);
  const latest = currentState();
  if (latest?.rolls?.gm && latest?.rolls?.ranger) await gmResolveCurrentPair(latest);
}

function independentObstacle(action, opponentAction) {
  if (action === "defend" && opponentAction === "defend") return 3;
  return 0;
}
function successfulEffectiveSuccesses(roll, passed) { return Number(roll?.successes ?? 0) + (passed ? Math.max(0, Number(roll?.conditionalSuccess ?? 0)) : 0); }
function capDisposition(value, start) { return Math.max(0, Math.min(Math.max(0, Number(start ?? 0)), Number(value ?? 0))); }

async function recordConflictLearning(state, roll, passed, versus) {
  if (!roll?.actorId) return;
  const sourceKey = roll.abilityKey ? `ability:${roll.abilityKey}` : roll.roleId ? `role:${roll.roleId}` : "";
  if (!sourceKey) return;
  const key = `${roll.actorId}:${sourceKey}`;
  if ((state.learningKeys ?? []).includes(key)) return;
  const actor = actorById(roll.actorId);
  if (!actor) return;
  if (roll.abilityKey) await recordAbilityTest(actor, roll.abilityKey, Boolean(passed));
  else if (roll.roleId) await recordHelperSkillTest(actor, roll.roleId, Boolean(passed));
  state.learningKeys = [...(state.learningKeys ?? []), key];
}

async function postConflictStepChat(state, pair, { gmRoll, rangerRoll, gmPassed, rangerPassed, gmMargin, rangerMargin, beforeGm, beforeRanger } = {}) {
  const gmAfter = Number(state.gm.disposition.current ?? 0), rangerAfter = Number(state.ranger.disposition.current ?? 0);
  const actionNo = Number(pair.index ?? state.currentIndex ?? 0) + 1;
  const sideLine = (label, action, roll, passed, margin) => `<div class="rg-conflict-chat-side"><b>${esc(label)} · ${esc(actionLabel(action))}</b>${roll?.trumped ? `<span class="rg-roll-state trumped">Trumped · no test</span>` : `<span>${diceFacesHtml(roll?.faces ?? [])} · <strong>${Number(roll?.successes ?? 0)} rolled successes</strong>${roll?.traitSuccessLevel3 ? ` · ${esc(roll.traitName || "Trait")} +1s when applicable` : ""}${passed ? ` · PASS${Number(margin||0)?` · margin ${Number(margin)}`:""}` : " · FAIL"}</span>`}</div>`;
  const content = `<div class="realm-guard rg-conflict-chat rg-conflict-step-chat"><div class="rg-custom-chat-tag">CONFLICT · EXCHANGE ${Number(state.exchange ?? 1)} · ACTION ${actionNo}</div><h3>${esc(actionLabel(pair.gmAction))} vs ${esc(actionLabel(pair.rangerAction))}</h3>${sideLine("GM / Opposition", pair.gmAction, gmRoll, gmPassed, gmMargin)}${sideLine("Rangers", pair.rangerAction, rangerRoll, rangerPassed, rangerMargin)}<div class="rg-conflict-disposition-chat"><span>Rangers <b>${Number(beforeRanger ?? rangerAfter)} → ${rangerAfter}</b></span><span>GM <b>${Number(beforeGm ?? gmAfter)} → ${gmAfter}</b></span></div><p>${pair.resultText || "Action resolved."}</p></div>`;
  await ChatMessage.create({ content });
}

async function gmResolveCurrentPair(state) {
  if (!game.user?.isGM || state.stage !== "action") return;
  const pair = currentPair(state); if (!pair) return;
  const next = clone(state); const gmRoll = next.rolls.gm; const rr = next.rolls.ranger;
  const gmMode = pair.gmMode, rangerMode = pair.rangerMode;
  let gmPassed = false, rPassed = false, gmMargin = 0, rMargin = 0;
  const gmBaseRaw = Number(gmRoll?.successes ?? 0), rBaseRaw = Number(rr?.successes ?? 0);
  let gmRaw = gmBaseRaw, rRaw = rBaseRaw;
  if (gmMode === "versus" || rangerMode === "versus") {
    if (gmRoll?.traitSuccessLevel3 && gmBaseRaw >= rBaseRaw) gmRaw += 1;
    if (rr?.traitSuccessLevel3 && rBaseRaw >= gmBaseRaw) rRaw += 1;
    gmPassed = gmMode !== "trumped" && gmRaw > rRaw; rPassed = rangerMode !== "trumped" && rRaw > gmRaw;
    let tieResolution = null;
    if (gmRaw === rRaw && gmMode === "versus" && rangerMode === "versus") {
      const rangerActor = actorById(pair.rangerActorId);
      const gmActor = actorById(next.gm.actorId);
      const rangerRole = rr?.roleId ? rangerActor?.items.get(rr.roleId) : null;
      const rangerSource = rangerRole ?? (rr?.skillName ? { name: rr.skillName } : null);
      const opposition = gmRoll?.roleId
        ? { kind: "role", name: gmRoll.skillName, rating: Number(gmRoll.base ?? 0) }
        : { kind: "ability", name: gmRoll?.skillName || "Nature", rating: Number(gmRoll?.base ?? 0) };
      if (rangerSource && rangerActor?._resolveAutomaticVersusTie && gmActor) {
        tieResolution = await rangerActor._resolveAutomaticVersusTie({
          role: rangerSource, opponent: gmActor, opposition, ownFaces: rr.faces ?? [], opponentFaces: gmRoll.faces ?? [], fateAlreadySpent: Boolean(rr.fateSpent)
        });
      }
      if (tieResolution?.resolved) {
        rPassed = Boolean(tieResolution.passed);
        gmPassed = !rPassed;
        rMargin = rPassed ? Math.max(0, Number(tieResolution.margin ?? 0)) : 0;
        gmMargin = gmPassed ? Math.max(0, Number(tieResolution.margin ?? 0)) : 0;
        pair.resultText = `<b>Versus tie resolved:</b> ${rPassed ? "Rangers" : "GM / Opposition"} wins${Number(tieResolution.margin ?? 0) ? ` · margin ${Number(tieResolution.margin)}` : ""}.`;
      } else {
        pair.resultText = `<b>VERSUS TIE:</b> standard tiebreaker remains unresolved. No disposition change until the table resolves it.`;
      }
    }
    if (!(gmRaw === rRaw && tieResolution?.resolved)) {
      const gmEff = gmRaw + (gmPassed ? Math.max(0, Number(gmRoll?.conditionalSuccess ?? 0)) : 0); const rEff = rRaw + (rPassed ? Math.max(0, Number(rr?.conditionalSuccess ?? 0)) : 0);
      gmMargin = gmPassed ? Math.max(0, gmEff - rRaw) : gmMargin; rMargin = rPassed ? Math.max(0, rEff - gmRaw) : rMargin;
    }
    if (gmRaw === rRaw && !tieResolution?.resolved) {
      const text = pair.resultText || `<b>VERSUS TIE:</b> tiebreaker is pending. Disposition and Learning remain unchanged until the tie is resolved.`;
      next.revealed = next.revealed.map(r => r.index === pair.index ? { ...r, resultText: text, tiePending: true } : r);
      await setPublicState(next);
      return;
    }
  } else {
    if (gmMode !== "trumped") { const ob = independentObstacle(pair.gmAction, pair.rangerAction); gmRaw = gmBaseRaw + (gmRoll?.traitSuccessLevel3 && gmBaseRaw >= ob ? 1 : 0); gmPassed = gmRaw >= ob; gmMargin = gmPassed ? Math.max(0, gmRaw + Math.max(0, Number(gmRoll?.conditionalSuccess ?? 0)) - ob) : 0; }
    if (rangerMode !== "trumped") { const ob = independentObstacle(pair.rangerAction, pair.gmAction); rRaw = rBaseRaw + (rr?.traitSuccessLevel3 && rBaseRaw >= ob ? 1 : 0); rPassed = rRaw >= ob; rMargin = rPassed ? Math.max(0, rRaw + Math.max(0, Number(rr?.conditionalSuccess ?? 0)) - ob) : 0; }
  }

  const beforeGm = Number(next.gm.disposition.current ?? 0);
  const beforeRanger = Number(next.ranger.disposition.current ?? 0);
  const applyAction = (side, action, mode, passed, margin, roll) => {
    if (mode === "trumped" || !passed) return;
    const own = next[side], oppSide = side === "gm" ? "ranger" : "gm", opp = next[oppSide];
    if (["attack", "feint"].includes(action)) {
      const damage = mode === "independent" ? successfulEffectiveSuccesses(roll, true) : margin;
      opp.disposition.current = Math.max(0, Number(opp.disposition.current ?? 0) - Math.max(0, damage));
    } else if (action === "defend") {
      own.disposition.current = capDisposition(Number(own.disposition.current ?? 0) + Math.max(0, margin), own.disposition.start);
    }
  };
  applyAction("gm", pair.gmAction, gmMode, gmPassed, gmMargin, gmRoll);
  applyAction("ranger", pair.rangerAction, rangerMode, rPassed, rMargin, rr);

  await recordConflictLearning(next, gmRoll, gmPassed, gmMode === "versus");
  await recordConflictLearning(next, rr, rPassed, rangerMode === "versus");

  const maneuverPending = [];
  if (pair.gmAction === "maneuver" && gmMode !== "trumped" && gmPassed && gmMargin > 0) maneuverPending.push({ side: "gm", margin: gmMargin });
  if (pair.rangerAction === "maneuver" && rangerMode !== "trumped" && rPassed && rMargin > 0) maneuverPending.push({ side: "ranger", margin: rMargin });
  pair.resultText = pair.resultText || `<b>Resolved:</b> GM ${gmRaw} successes${gmPassed ? ` · margin ${gmMargin}` : ""} · Rangers ${rRaw} successes${rPassed ? ` · margin ${rMargin}` : ""}.`;
  next.revealed = next.revealed.map(r => r.index === pair.index ? { ...r, resultText: pair.resultText, tiePending: false, gmPassed, rangerPassed: rPassed, gmMargin, rangerMargin: rMargin, gmRoll: gmRoll?.trumped ? null : gmRoll, rangerRoll: rr?.trumped ? null : rr } : r);
  await postConflictStepChat(next, pair, { gmRoll, rangerRoll: rr, gmPassed, rangerPassed: rPassed, gmMargin, rangerMargin: rMargin, beforeGm, beforeRanger });

  const gmZero = Number(next.gm.disposition.current ?? 0) <= 0, rangerZero = Number(next.ranger.disposition.current ?? 0) <= 0;
  if (gmZero || rangerZero) {
    next.outcome = { winner: gmZero && rangerZero ? "tie" : gmZero ? "ranger" : "gm", endedExchange: next.exchange, endedAction: next.currentIndex + 1 };
    next.stage = "compromise"; next.pendingManeuver = null; next.rolls = { gm: null, ranger: null };
    await setPublicState(next); return;
  }
  if (maneuverPending.length) {
    next.pendingManeuverQueue = maneuverPending; next.pendingManeuver = maneuverPending[0]; next.stage = "maneuver"; next.rolls = { gm: null, ranger: null };
    await setPublicState(next); return;
  }
  await advanceAfterAction(next);
}

async function chooseManeuver(choice, state) {
  const pending = state.pendingManeuver; if (!pending || state.stage !== "maneuver") return;
  const side = pending.side; const actor = side === "gm" ? actorById(state.gm.actorId) : actorById(currentPair(state)?.rangerActorId);
  if (!(side === "gm" ? game.user?.isGM : (game.user?.isGM || actor?.isOwner))) return;
  if (!game.user?.isGM) {
    game.socket.emit(SOCKET_CHANNEL, { type: "conflict-intent", intent: "maneuverChoice", conflictId: state.id, senderId: game.user.id, payload: { choice } });
    return;
  }
  await gmApplyManeuverChoice({ choice }, state);
}

async function postConflictManeuverChat(state, pair, { side, choice, margin, disarmedName = "" } = {}) {
  const label = side === "gm" ? "GM / Opposition" : "Rangers";
  const targetLabel = side === "gm" ? "Rangers" : "GM / Opposition";
  const detail = choice === "impede"
    ? `${targetLabel} suffers -1D on its next test.`
    : choice === "position"
      ? `${label} gains +2D on its next test.`
      : choice === "disarm"
        ? (disarmedName ? `${targetLabel} has ${esc(disarmedName)} disabled for the rest of the conflict.` : `Disarm chosen; no supported equipped Gear Item was available, so adjudicate a natural weapon or trait manually.`)
        : choice === "combo"
          ? `${targetLabel} suffers -1D and ${label} gains +2D on the next tests.`
          : `Maneuver effect applied.`;
  const content = `<div class="realm-guard rg-conflict-chat rg-conflict-step-chat rg-conflict-maneuver-chat"><div class="rg-custom-chat-tag">CONFLICT · EXCHANGE ${Number(state.exchange ?? 1)} · ACTION ${Number(pair?.index ?? state.currentIndex ?? 0) + 1}</div><h3>Maneuver · ${esc(label)}</h3><p><b>${esc(String(choice ?? "Maneuver").replace(/^./, c => c.toUpperCase()))}</b> · margin ${Number(margin ?? 0)}</p><p>${esc(detail)}</p></div>`;
  await ChatMessage.create({ content });
}

async function gmApplyManeuverChoice(payload, state = currentState(), sender = null) {
  if (!game.user?.isGM || !state?.pendingManeuver || state.stage !== "maneuver") return;
  const pending = state.pendingManeuver; const side = pending.side; const pair = currentPair(state);
  if (side === "ranger" && sender) {
    const actor = actorById(pair?.rangerActorId); if (!actor?.testUserPermission(sender, CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER)) return;
  }
  const margin = Number(pending.margin ?? 0); const choice = payload.choice;
  if (choice === "impede" && margin < 1 || choice === "position" && margin < 2 || ["disarm","combo"].includes(choice) && margin < 3) return;
  const next = clone(state); const opp = side === "gm" ? "ranger" : "gm";
  let disarmedName = "";
  if (choice === "impede" || choice === "combo") next.effects[opp].nextDice = Number(next.effects[opp].nextDice ?? 0) - 1;
  if (choice === "position" || choice === "combo") next.effects[side].nextDice = Number(next.effects[side].nextDice ?? 0) + 2;
  if (choice === "disarm") {
    const targetActor = opp === "gm" ? actorById(next.gm.actorId) : actorById(pair?.rangerActorId);
    const gear = enabledGear(targetActor, next, opp);
    if (gear.length) {
      const selection = await chooseDisarmTarget(targetActor, gear, side === "gm" || game.user?.isGM);
      if (selection) {
        next.effects[opp].disabledGearIds = [...new Set([...(next.effects[opp].disabledGearIds ?? []), selection])];
        disarmedName = gear.find(item => item.id === selection)?.name ?? "Gear";
      }
    } else next.log.push(`Maneuver Disarm: ${targetActor?.name ?? "target"} has no equipped Gear Item to disable; adjudicate a natural weapon/trait manually.`);
  }
  next.log.push(`${side === "gm" ? "GM" : "Rangers"} Maneuver: ${choice}.`);
  await postConflictManeuverChat(next, pair, { side, choice, margin, disarmedName });
  const queue = [...(next.pendingManeuverQueue ?? [])]; queue.shift(); next.pendingManeuverQueue = queue; next.pendingManeuver = queue[0] ?? null;
  if (!next.pendingManeuver) await advanceAfterAction(next); else await setPublicState(next);
}

async function chooseDisarmTarget(actor, gear) {
  const options = gear.map(g => `<option value="${g.id}">${esc(g.name)}</option>`).join("");
  return await foundry.applications.api.DialogV2.wait({
    window: { title: `Realm Guard · Disarm ${actor.name}` }, content: `<div class="rg-disarm-dialog"><p>Choose one equipped weapon or piece of gear to disable for the rest of this conflict.</p><label>Target <select name="gearId">${options}</select></label></div>`, modal: false, rejectClose: false,
    buttons: [{ action: "ok", label: "Disarm", icon: "fa-solid fa-hand", default: true, callback: (_e,b) => b.form?.elements?.gearId?.value || null }, { action: "cancel", label: "Cancel", callback: () => null }]
  });
}

async function advanceAfterAction(state) {
  const next = clone(state); next.rolls = { gm: null, ranger: null }; next.pendingManeuver = null; next.pendingManeuverQueue = [];
  if (next.currentIndex < 2) { next.currentIndex += 1; next.stage = "ready"; await setPublicState(next); await revealCurrentAction(next); return; }
  next.actionCounts = next.pendingActionCounts ?? next.actionCounts; next.lastRangerActorId = next.pendingLastRangerActorId ?? next.lastRangerActorId;
  next.pendingActionCounts = null; next.pendingLastRangerActorId = null;
  next.exchange += 1; next.currentIndex = 0; next.locks = { gm: false, ranger: false }; next.stage = "gmPlan"; next.revealed = [];
  const p = privateState(); p.gmPlan = []; p.rangerPlan = []; await setPrivateState(p); lockedPlanCache.set(next.id, { gmPlan: [], rangerPlan: [] }); draftPlans.delete(next.id); weaponDrafts.delete(next.id);
  next.log.push(`Exchange ${next.exchange} begins.`); await setPublicState(next);
}

async function finishConflict(state) {
  if (!game.user?.isGM || state.stage !== "compromise") return;
  const text = document.getElementById("rg-conflict-compromise-text")?.value?.trim() || "";
  const next = clone(state); next.compromise = { text, grade: next.outcome?.winner === "tie" ? "tie" : compromiseGrade((next.outcome?.winner === "ranger" ? next.ranger : next.gm).disposition.start, (next.outcome?.winner === "ranger" ? next.ranger : next.gm).disposition.current) }; next.stage = "complete"; next.active = false;
  const winner = next.outcome?.winner === "ranger" ? "Rangers" : next.outcome?.winner === "gm" ? "GM / Opposition" : "Tie";
  await ChatMessage.create({ content: `<div class="realm-guard rg-conflict-chat"><h3>CONFLICT COMPLETE · ${esc(next.name)}</h3><p><b>Winner:</b> ${esc(winner)} · <b>Type:</b> ${esc(conflictTypeLabel(next.type))}</p><p><b>Disposition:</b> Rangers ${next.ranger.disposition.current}/${next.ranger.disposition.start} · GM ${next.gm.disposition.current}/${next.gm.disposition.start}</p><p><b>Ranger Goal:</b> ${esc(next.ranger.goal || "—")}</p><p><b>GM Goal:</b> ${esc(next.gm.goal || "—")}</p>${text ? `<p><b>Compromise:</b> ${esc(text)}</p>` : ""}</div>` });
  await setPublicState(next); await setPrivateState({}); lockedPlanCache.delete(next.id);
  document.getElementById(WINDOW_ID)?.remove();
  ui.notifications.info("Realm Guard: Conflict complete.");
}

async function abortConflict() {
  if (!game.user?.isGM) return;
  const state = currentState(); if (!isActive(state)) return;
  const confirmed = await foundry.applications.api.DialogV2.confirm({ window: { title: "Abort Realm Guard Conflict?" }, content: "<p>Abort the current conflict? No Actor data or resources already spent will be rolled back.</p>", modal: false });
  if (!confirmed) return;
  await setPublicState(null); await setPrivateState({}); draftPlans.clear(); weaponDrafts.clear(); lockedPlanCache.clear(); document.getElementById(WINDOW_ID)?.remove();
}

async function onSocket(message) {
  if (!game.user?.isGM || message?.type !== "conflict-intent") return;
  const state = currentState(); if (!state || state.id !== message.conflictId) return;
  const sender = game.users.get(message.senderId); if (!sender) return;
  if (message.intent === "submitRangerPlan") return gmHandleRangerPlan(message, state);
  if (message.intent === "submitDisposition") {
    const captain = actorById(state.ranger.captainId); if (!captain?.testUserPermission(sender, CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER)) return;
    return gmApplyDisposition(message.payload, state);
  }
  if (message.intent === "submitActionRoll") return gmApplyActionRoll(message.payload, state, sender);
  if (message.intent === "maneuverChoice") return gmApplyManeuverChoice(message.payload, state, sender);
}

function onConflictSettingUpdate(setting) {
  if (setting.key !== `${SYSTEM_ID}.${PUBLIC_SETTING}`) return;
  const state = currentState();
  if (isActive(state)) renderConflictWindow(state);
  else document.getElementById(WINDOW_ID)?.remove();
}

export function installConflictEngine() {
  game.settings.register(SYSTEM_ID, PUBLIC_SETTING, { name: "Realm Guard Conflict State", scope: "world", config: false, type: String, default: "" });
  game.settings.register(SYSTEM_ID, PRIVATE_SETTING, { name: "Realm Guard Conflict Private State", scope: "client", config: false, type: String, default: "" });
  registerGmDockTool({ id: "conflict", icon: "fa-solid fa-khanda", tooltip: "Open Conflict Engine", order: 15, onClick: startConflictDialog });
  Hooks.once("ready", () => {
    game.socket.on(SOCKET_CHANNEL, onSocket);
    const state = currentState(); if (isActive(state) && isParticipantOwner(state)) { dismissedConflictId = null; renderConflictWindow(state, { force: true }); }
  });
  Hooks.on("updateSetting", onConflictSettingUpdate);
}

export function openConflictWindow() {
  const state = currentState();
  if (!isActive(state)) return game.user?.isGM ? startConflictDialog() : ui.notifications.info("Realm Guard: No active conflict.");
  dismissedConflictId = null; renderConflictWindow(state, { force: true });
}
