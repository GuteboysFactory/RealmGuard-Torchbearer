# Realm Guard / Torchbearer v1.0.8.3 - NPC Layout & Token Portrait QA

**Foundry target:** 13.351  
**Build status:** QA hotfix  
**Baseline:** v1.0.8.2 QA / v1.0.7.1 GOLD  
**Migration:** none destructive

## 1. Upgrade / smoke
- [ ] Install v1.0.8.3 over the current test World.
- [ ] World opens without red Realm Guard console errors.
- [ ] Existing Rangers/NPCs, Items, progression, templates and tokens remain intact.

## 2. NPC GM Notes layout
- [ ] Open a populated NPC at normal width.
- [ ] GM Notes appears beneath Quick Skills in the left column only and no longer spans the full NPC sheet.
- [ ] Notes remain editable and persist after closing/reopening the sheet.
- [ ] Resize narrower/wider: Notes stays aligned with the left column and does not overlap the right-side panels.

## 3. Token Builder explicit commit + NPC portrait
- [ ] Open an NPC with a full portrait source and open Token Builder.
- [ ] Drag/zoom/Center/Fit/Fill change preview only; Cancel changes neither portrait nor token.
- [ ] Reopen, frame the image and press Create / Save Token.
- [ ] Generated round PNG becomes the NPC prototype token.
- [ ] The same generated round PNG also becomes the NPC Actor portrait.
- [ ] Reopen Token Builder: it starts from the preserved original full artwork, not the round token output.
- [ ] Save again with different framing: NPC portrait and prototype token both update to the newly generated token.
- [ ] If Update placed tokens is enabled, matching current-scene tokens update; if disabled, placed tokens are left alone.

## 4. Ranger regression
- [ ] Ranger Token Builder still saves prototype-token art correctly.
- [ ] Ranger portrait is not unexpectedly replaced by the token output.

## 5. v1.0.8.2 regression
- [ ] NPC Conditions remain readable in one column.
- [ ] Roll Dialog top grouping remains correct.
- [ ] Trait session rules, Skill Learned guard, Custom Roll, Help/Synergy, Conflict and End Session remain functional.

## Result
**Status:** [ ] PASS  [ ] FAIL  [ ] BLOCKED  
**Blocking bugs:**  
**Non-blocking notes:**  
**Approved as v1.0.8.3 GOLD:** [ ] YES  [ ] NO
