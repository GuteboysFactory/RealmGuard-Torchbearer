# Realm Guard / Torchbearer v1.0.8.3 - Static QA

**Foundry target:** 13.351  
**Build:** v1.0.8.3 - NPC Layout & Token Portrait Hotfix  
**Result:** PASS

- PASS - all 33 `.mjs` files pass `node --check`.
- PASS - all shipped JSON files parse successfully.
- PASS - changed NPC template has one GM Notes panel inside the new left-column stack.
- PASS - Token Builder keeps explicit `Create / Save Token` commit flow.
- PASS - original token source artwork is preserved in `flags.realm-guard.tokenBuilderSourcePortrait`.
- PASS - explicit token save updates NPC `img` to the generated round token while Ranger portraits remain unchanged.
- PASS - package version is `1.0.8.3` and internal system id remains `realm-guard`.
- PASS - no destructive migration added.

**Live QA still required:** Foundry layout/rendering, Token Builder save behavior, Actor portrait refresh, prototype/placed token refresh and regression checks in `TEST_PROTOCOL_v1.0.8.3.md`.
