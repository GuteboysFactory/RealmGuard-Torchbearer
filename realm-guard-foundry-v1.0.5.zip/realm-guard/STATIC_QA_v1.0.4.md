# Realm Guard / Torchbearer v1.0.4 - Static QA

**Foundry target:** 13.351  
**Baseline:** v1.0.3 GOLD  
**Status:** PASS (static) / awaiting live QA

## Checks performed

- PASS - all `.mjs` files pass `node --check`.
- PASS - `system.json` parses and reports version `1.0.4`.
- PASS - Manual, Rules Reference, World Health Audit target and initialization log are aligned to v1.0.4.
- PASS - Recruitment state defaults `allowEnemyServant` to `false`.
- PASS - Recruitment Step 9 exposes `Allow Servants of the Enemy as personal Enemies (House Rule)`.
- PASS - Enemy field is labelled `Enemy's People / Type` with explanatory text.
- PASS - printed-rule Free Peoples remain available: Dúnadan, Dwarf, Elf, Hobbit and Man.
- PASS - House Rule choices are present: Orc, Troll, Warg, Spider and Other servant of the Enemy.
- PASS - validation blocks a House Rule Enemy choice unless the opt-in checkbox is enabled.
- PASS - House Rule choice is persisted as Actor Recruitment metadata `recruitmentEnemyHouseRule`.
- PASS - no Actor schema migration was added.
- PASS - ZIP archive integrity verified.

## Live QA still required

Run `TEST_PROTOCOL_v1.0.4.md` in Foundry VTT 13.351 before promoting v1.0.4 to GOLD.
