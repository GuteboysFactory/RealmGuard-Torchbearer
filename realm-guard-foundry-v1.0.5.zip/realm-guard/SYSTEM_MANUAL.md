# Realm Guard / Torchbearer - System Manual

**Release:** v1.0.0  
**Foundry target:** VTT 13.351  
**Internal system id:** `realm-guard`

## What this system is

Realm Guard / Torchbearer is a private Foundry VTT game system built from a deliberate mix of rules rather than a one-book conversion.

Rule-source order:

1. **Realm Guard: Rangers of the North** takes priority where the hack defines or replaces a rule.
2. **Mouse Guard Roleplaying Game 2nd Edition** supplies inherited core procedures where Realm Guard does not replace them.
3. **Torchbearer 2nd Edition** contributes selected compatible ideas only where the project deliberately adopted them.
4. **Realm Guard / Torchbearer Foundry expansions** are project-specific additions and are identified as such in the integrated Rules Reference.

The in-Foundry manual uses four labels:

- **RULE** - a tabletop rule used by the system.
- **AUTOMATED** - Foundry handles the bookkeeping.
- **GM CALL** - fictional/table judgement is still required.
- **RG/TB FOUNDRY** - a project-specific expansion or convenience layer.

This manual and the permanent **Realm Guard / Torchbearer - Rules Reference** Journal summarize the rules that the Foundry system actually implements. They do not reproduce the source books verbatim.

## Global Help / Manual

Every user receives a compact **book icon in Foundry's sidebar**. It opens the System Manual & Rules Reference from any normal workspace without requiring a return to chat.

The same manual is also available from chat-side system controls and, for GMs, from the GM Dock.

The manual can open the permanent Rules Reference Journal. GMs also get a shortcut from the manual to World Health Audit.

## Quick Start

Players use **Create Ranger** for rules-driven Recruitment and then use the Ranger sheet for Skills, Abilities, Nature, Conditions, Inventory, Tokens, Levels and Talents.

GMs use the **GM Dock** for GM Control, Conflict Engine, Turn Manager, End Session, Starter Compendiums, Content Studio, World Health Audit and the manual.

A normal session can flow:

`scene play -> rolls / Conditions -> Conflict if needed -> Players' Turn / Recovery if Structured Mode is used -> End Session -> Start Next Session`

## Recruitment

**Create Ranger** is the authoritative player-character path. GUIDED and QUICK modes use the same rules; GUIDED contains more explanation.

The Recruitment flow covers Concept, Station/Age, Dúnadan Nature, Homeland, Natural Talent, Life Experience, Service, Specialty, Wises, Resources/Circles, Traits, relationships, Belief/Goal/Instinct and starting Gear.

For the personal Enemy relationship, the printed Realm Guard restriction remains the default: choose among the Free Peoples rather than a servant of the Enemy. Recruitment Step 9 also offers the explicit opt-in **Allow Servants of the Enemy as personal Enemies (House Rule)**. When enabled, Orc, Troll, Warg and Spider become available as Enemy types. The choice is a table variant, not a change to the source rule.

Finished Rangers are created in `Actors > PC`; the folder is created on demand.

The separate **Recruitment Guide** explains the same creation sequence without requiring character creation.

## Rolls, Learning, Fate and Persona

Skill, Ability, Nature, Versus and Beginner's Luck tests use the common Roll Dialog. Obstacle defaults to 1 and Modifier to 0.

The dialog can expose applicable Conditions, Traits, unrated Wises, Teamwork, Persona, Fate/Open 6s, Tokens of Power and Talents.

Trained Skills track Pass/Fail Learning. Untrained Skills use Beginner's Luck and their own attempt track before becoming trained.

Current Fate and Persona are spendable resources. A roll may spend 0-3 Persona for +0D to +3D; supported Nature spends are additional Persona costs where applicable. Lifetime Spent Fate/Persona increases only when a real spend is committed. Rewards and manual resource corrections do not count toward lifetime progression.

## Turn Manager, Checks and Recovery

Structured Mode uses GM Turn and Players' Turn. Each participating Ranger begins Players' Turn with one Free Test. Additional Players' Turn tests cost Checks. Group play enforces the action-rotation rule; solo play is exempt.

Trait Against can earn Checks in the intended GM Turn context. Teamwork Help comes from an appropriate Skill; a relevant Wise can instead contribute +1D through I Am Wise. Traits do not Help another Ranger. Checks can be passed to patrol-mates under the implemented rules.

Recovery order is:

`Hungry & Thirsty -> Angry -> Tired -> Injured -> Strained`

Players' Turn recovery uses the Free Test first and then Checks. Supported GM Turn recovery costs two Checks. Free Play disables Turn/Check test costs while preserving the underlying character data and recovery mechanics.

## Conditions

Conditions are Realm Guard Items synchronized with Foundry Active Effects for token display.

The canonical set is Angry, Strained, Tired, Hungry & Thirsty, Afraid, Injured and Fresh. Strained is the Realm Guard replacement for the old Sick default. Fresh is a Foundry convenience Condition.

Conditions can be managed from the global Conditions dropdown, Ranger/NPC sheets and token HUD.

## Inventory, Gear and Tokens of Power

Inventory & Gear uses a paper-doll interface with Left Hand, Right Hand, Head, Neck, Cloak, Torso, Belt, Pocket and Feet plus Containers and Unassigned Gear. Two-handed items lock the opposite hand.

Tokens of Power appear at the top of Inventory & Gear. The system implements Level 1/2/3 behavior, linked Skills/uses and once-session state. Specific-use/manual effects and Scale of Might applicability remain explicit table judgement where automation cannot determine them safely.

## Card-driven Conflict Engine

Conflicts use secret three-card scripting for both sides. The action cards are Attack, Defend, Feint and Maneuver. GM and Ranger cards use separate visual identities and opposing unrevealed cards stay hidden.

The engine supports Starting Disposition, action interaction, Realm Guard conflict Skill mapping, Conflict Captain assignments, Teamwork, selected weapon qualities, Maneuvers, Disposition, ties, Learning and final Compromise.

## Levels and Talents

Levels & Talents are an explicit **Realm Guard / Torchbearer Foundry expansion** inspired by the selected Torchbearer 2E concept that spent Fate/Persona can drive level advancement.

Rangers begin at Level 1. Both lifetime Fate and Persona thresholds must be reached. From Level 2 onward the Ranger receives one Talent slot per Level through Level 10.

Talents may be Passive, Once per Session or Once per Conflict and may be linked to a Skill, Ability or a table-approved general use.

This layer does not import Torchbearer classes, Town/Camp/Grind or unrelated Torchbearer subsystems.

## NPC and GM Tools

Quick NPC creates compact NPCs in `Actors > NPC`, creating the folder on demand. Rank-aware default loadouts are Foundry convenience presets and do not claim to be new source rules.

GM Control provides Quick NPC Roll, Conditions, group resources and shortcuts to Turn Manager, Conflict Window and Content Studio.

## Starter Compendiums

A clean GM world receives eight Starter Compendiums:

- Skills
- Traits
- Wises
- Conditions
- Gear
- Tokens of Power
- Talents
- NPC Templates

**Add Missing Entries** is non-destructive. Missing starter documents can be restored without overwriting edited/custom documents.

Wises remain unrated; Wises 2.0 is not part of this project.

## Content Studio

Content Studio is the GM authoring tool for creating or duplicating Realm Guard / Torchbearer content through type-aware forms and a **Review Before Create** gate.

It supports World content, selected Actors, recommended custom Compendiums and compatible writable Compendiums. Duplicate & Modify never edits the source and strips Starter Library identity from custom copies.

Normal player Rangers should still use Create Ranger / Recruitment rather than the admin Actor-template flow.

## End Session

End Session is GM-only. It reviews Belief, Goal and Instinct, proposes Fate/Persona awards and requires GM approval before resources are applied.

MVP and Workhorse are separate one-Ranger awards and cannot go to the same Ranger. Embodiment represents portrayal rather than MVP and may apply to multiple Rangers, but not the entire group. In a one-Ranger session, the sole Ranger may receive Embodiment as a solo-play exception in the Foundry workflow.

Start Next Session resets supported once-session state such as Token of Power and Talent uses while preserving progression and World content.

## World Health Audit

World Health Audit is a GM-only, read-only diagnostic. It checks versions, canonical Skill/Condition duplicates, resource bounds, progression consistency, invalid 2H occupancy, Talent/Token configuration, Starter Compendiums and basic World structure.

It reports; it does not repair, move, delete or reset World data.

## Permanent Rules Reference Journal

On first GM load of v1.0, the system creates a player-readable Journal folder **Realm Guard / Torchbearer** and the Journal:

**Realm Guard / Torchbearer - Rules Reference**

The Journal is created only if it does not already exist. Existing Journal content is not overwritten by normal world loading.

The integrated manual and the created Journal use the same in-system rules-reference definitions for v1.0.

## World Backup and Transfer

The system package and a Foundry World are separate.

Installing Realm Guard / Torchbearer on another server does **not** move the campaign. Rangers, NPCs, Scenes, Journals, campaign Items, custom Compendiums, progression and campaign state live in the World data.

Before an upgrade or move:

1. Back up the current Foundry World.
2. Install a compatible Realm Guard / Torchbearer version on the destination.
3. Transfer/restore the actual World data using the server/host backup method.
4. Install modules/external assets that the World requires.
5. Open the copied World and run World Health Audit.

## Safe Upgrade Policy

v1.0 keeps the internal Foundry system id `realm-guard` so existing Worlds continue to identify the same system after the display-name change.

The v1.0 upgrade must not reset or reorganize existing Actors, NPCs, Scenes, Journals, Items, Compendiums, Inventory, Conditions, Recruitment data, Tokens, Talents or progression.

If something fails, record the exact action, copy the first relevant F12 Console error and run World Health Audit. Do not delete World data to troubleshoot a system bug without a verified backup.

## Rules Reference

See `RULES_REFERENCE.md` for the shipped text reference. The same reference is available inside Foundry through the System Manual and the permanent Rules Reference Journal.


## v1.0.5 workflow notes

- RG/TB system dialogs are non-modal: leave them open and interact with other Foundry windows as needed.
- Beginner's Luck may Tap Nature when Tap Nature is otherwise legal. Nature dice are added after the Beginner's Luck halving.
- Trained Skills advance automatically when both Pass and Fail requirements are met; there is no manual Advance step.
- Character Levels rise immediately when cumulative committed Fate/Persona spend reaches a threshold. If the new Level grants an unclaimed Talent choice, the Talent browser is offered immediately; closing it leaves the Talent choice pending.
- The GM Dock can be dragged by its RG/TB grip and Reset Position returns it beside the Hotbar.
- RG/TB system chat uses a dark presentation independent of Foundry light/dark appearance.
