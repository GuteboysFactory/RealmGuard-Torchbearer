# Realm Guard / Torchbearer v1.0.3 - Static QA

**Foundry target:** 13.351  
**Status:** PASS - static/package checks only  
**Live QA:** still required via `TEST_PROTOCOL_v1.0.3.md`

## Static checks completed

- PASS - `system.json` parses and reports version `1.0.3`.
- PASS - internal system id remains `realm-guard`.
- PASS - all `.mjs` files pass `node --check`.
- PASS - main Roll Dialog exposes numeric Persona selection from 0 to 3, limited by current Persona.
- PASS - standard Skill, Ability, Nature, Automatic Versus and Beginner's Luck pools normalize Persona bonus dice to 0-3.
- PASS - Beginner's Luck keeps Persona post-halving.
- PASS - Quick NPC Roll exposes Persona 0-3 and spends the selected amount once after a committed roll.
- PASS - Conflict roll dialog exposes Persona 0-3 and the conflict engine spends/records the selected amount once.
- PASS - Teamwork helper source generation no longer includes Trait Items.
- PASS - Teamwork helper source generation includes trained Skills and Wises; help text names Skill/Wise and I Am Wise.
- PASS - Nature scope UI no longer uses the ambiguous `Relationship` label; both direct Nature and Tap Nature use Within/Against Nature descriptor wording.
- PASS - End of Session blocks all-participant Embodiment only when more than one Ranger participates, allowing the explicit solo exception.
- PASS - generic Realm Guard chat-card contrast fallback is present for non-roll cards such as ADVANCEMENT.
- PASS - integrated Rules Reference and shipped manual/reference text describe the corrected Persona/Teamwork/solo-Embodiment behavior.
- PASS - no data migration was added.

## Live checks still required

Static QA cannot prove Foundry ApplicationV2 rendering, resource mutation timing, light-theme chat appearance or End of Session interaction state. Run the focused Persona, Teamwork, Nature wording, solo Embodiment and chat-contrast tests in `TEST_PROTOCOL_v1.0.3.md` before GOLD/public promotion.
