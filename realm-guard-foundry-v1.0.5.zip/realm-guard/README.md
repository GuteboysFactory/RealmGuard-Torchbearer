# Realm Guard / Torchbearer for Foundry VTT

**Version:** 1.0.5 - Gameplay & UI Polish Hotfix  
**Target:** Foundry VTT 13.351  
**Status:** QA / v1.0.5 gameplay & UI polish  
**Verified GOLD baseline:** v1.0.3



## v1.0.5 Gameplay & UI Polish Hotfix

- Realm Guard / Torchbearer DialogV2 workflows are non-modal so an open system window no longer blocks interaction with the rest of Foundry.
- Beginner's Luck can **Tap Nature** (except the existing Resources/Circles exclusions); Nature dice are added **after** the Beginner's Luck halving and use the normal Within/Against Nature tax rules.
- Trained Skill advancement is now **automatic** as soon as required Pass and Fail marks are present. The manual Advance button is removed so additional eligible tests are not lost while waiting for a click.
- Skill advancement chat is rebuilt as a dark, celebratory **Congratulations** card.
- Character Level advancement remains immediate when cumulative spent Fate/Persona crosses a threshold. Level-up chat is now a large celebration card and an available Talent choice opens automatically without delaying the level increase.
- GM Dock can be dragged to another screen position. Its position is saved per user and a Reset Position control restores the normal hotbar-adjacent placement.
- Full RG/TB chat presentation audit: system-generated messages claim a consistent dark Realm Guard surface, including the Foundry message wrapper, so light-theme white cards no longer undermine readability.
- v1.0.4 Recruitment House Rule UX remains included.

## v1.0.4 Recruitment House Rule UX

This patch keeps the printed Realm Guard Recruitment restriction as the default while adding an explicit opt-in table variant:

- **Allow Servants of the Enemy as personal Enemies (House Rule)** is available in Recruitment Step 9.
- The option is **off by default**. With it off, the printed-rule Free Peoples choices remain the intended path.
- When enabled, the Ranger may choose **Orc, Troll, Warg, Spider or another servant of the Enemy** as the recurring personal Enemy.
- The Enemy selector is relabelled **Enemy's People / Type** and includes a short explanation so the question is less ambiguous.
- House-rule use is preserved in Recruitment metadata on the created Actor; no Actor schema migration is required.

## v1.0.3 GM Playtest hotfix

This patch addresses the first external GM playtest feedback without changing World data or introducing a migration:

- Persona spending is now selectable from **0-3 points** for **+0D to +3D** on supported rolls.
- Teamwork no longer offers a helper's **Trait**. Helpers can use an appropriate trained **Skill**, or a relevant **Wise** for +1D through *I Am Wise*.
- Nature wording now uses **Test is: Within Nature descriptors / Against Nature descriptors** instead of the ambiguous Relationship label.
- End of Session allows **Embodiment** for the sole Ranger in a one-player session; the normal not-everyone restriction remains for groups of two or more.
- Realm Guard chat cards get a theme-independent high-contrast fallback so cards such as **ADVANCEMENT** remain readable in Foundry's light chat presentation.
- v1.0.2's sidebar Manual launcher and v1.0.1 Join Page behavior are retained.

## v1.0.2 Sidebar Manual UI hotfix

The previous floating **RG/TB** pill has been removed. The global Manual & Rules Reference launcher is now an icon-only **book button inside Foundry's sidebar tab strip**, using Foundry's own `ui-control` styling where available. The button keeps the same manual-opening behavior and tooltip without floating over the canvas/chat area.

The v1.0.1 World Description behavior is retained: Foundry's native **Edit World > World Description** remains the single source for Join Page World Description text. No automatic World Description content is seeded.

## v1.0 identity

The visible system name is now **Realm Guard / Torchbearer**. The internal Foundry package id remains `realm-guard` so existing Worlds continue to identify the same game system after upgrading from the verified 0.x line.

This private game system deliberately combines:

1. **Realm Guard: Rangers of the North** rules where that hack defines/overrides play;
2. inherited **Mouse Guard RPG 2nd Edition** core mechanics where Realm Guard does not replace them;
3. selected compatible **Torchbearer 2nd Edition** ideas that were deliberately adopted; and
4. clearly marked **Realm Guard / Torchbearer Foundry expansions**.

The release is not presented as a one-to-one digital edition of any single source book.


## Join page presentation

v1.0.3 retains the v1.0.1 dedicated **Realm Guard / Torchbearer** world/login background and uses Foundry's native **World Description** as the authoritative Join Page text. The system manifest still declares the same artwork as the default background for new Realm Guard / Torchbearer Worlds. Existing Worlds keep their World data; the join-page theme is presentation-only and does not move, rewrite or auto-fill campaign content.

## Global Manual & Rules Reference

v1.0.3 retains the icon-only **book button in Foundry's sidebar** for every user. The manual can be opened while working elsewhere in Foundry instead of requiring a return to chat.

The integrated manual now has two layers:

- **Using the Foundry System** - where the tools live and how the implemented play loop works.
- **Rules Reference** - concise summaries of the rules and automation boundaries actually used by the system.

Rules are marked as:

- `RULE`
- `AUTOMATED`
- `GM CALL`
- `RG/TB FOUNDRY`

## Permanent Rules Reference Journal

On first GM load, v1.0 creates a player-readable Journal folder **Realm Guard / Torchbearer** and the Journal **Realm Guard / Torchbearer - Rules Reference** if it does not already exist.

Normal world loading does not overwrite an existing Rules Reference Journal.

The same v1.0 rules-reference definitions are used by the integrated manual and the seeded Journal.

Shipped text references:

- `SYSTEM_MANUAL.md`
- `RULES_REFERENCE.md`

## Existing v0.26 GOLD features retained

- Recruitment 2.0 / Create Ranger / Recruitment Guide
- Skills, Learning, Beginner's Luck, Nature, Traits, Wises, Teamwork, Fate/Persona
- Conditions, Recovery, Optional Turn Manager / Free Play
- Inventory & Gear paper-doll and Containers
- Tokens of Power
- Levels & Talents
- Card-driven Conflict Engine
- Quick NPC / compact NPC sheet / GM Control
- Starter Compendiums
- GM Content Studio
- End of Session
- World Health Audit
- non-destructive World upgrade/transfer policy

## Data preservation

v1.0 does not rename the internal system id and does not deliberately move/reset existing World data. Existing Actors, NPCs, Scenes, Journals, Items, Compendiums, Recruitment, Inventory, Conditions, Tokens, Talents and progression must remain intact.

Use `TEST_PROTOCOL_v1.0.4.md` for this patch QA. Promote v1.0.4 only after the focused Recruitment House Rule checks and regression smoke pass in Foundry 13.351.

### Final v1.0 Join Game correction
v1.0.3 keeps the approved ultra-wide Realm Guard / Torchbearer release artwork while restoring Foundry's native World Description as the authoritative Join Page text source. Join Game layout styling aligns the live Foundry controls with the artwork without injecting campaign/system copy into the description panel.

## Project repository
Planned distribution repository: https://github.com/GuteboysFactory/RealmGuard-Torchbearer

The v1.0.4 QA package records the project URL only. Update the public manifest/download target after v1.0.4 passes live QA and the ZIP is published.

### Join Page World Description
Realm Guard / Torchbearer v1.0.3 displays the description saved in Foundry under **Edit World > World Description**. If the GM leaves that field blank, the Join Page description content is intentionally blank. The system does not write to the World document.
