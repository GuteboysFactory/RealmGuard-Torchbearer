# Realm Guard / Torchbearer v1.0.5 - Static QA

**Foundry target:** 13.351  
**Build:** v1.0.5  
**Baseline package:** v1.0.4  
**Verified GOLD baseline:** v1.0.3  
**Status:** STATIC PASS / live QA required

## Static checks

- [x] `system.json` parses and reports version `1.0.5`.
- [x] 26 JavaScript module files pass `node --check`.
- [x] Remaining `modal: true` occurrences in RG/TB module/sheet code: **0**.
- [x] Manual Skill Advance action/button occurrences: **0**.
- [x] Beginner's Luck Roll Dialog can expose `tapNature` and `natureScope`.
- [x] Beginner's Luck roll math adds Nature after `Math.ceil(preHalf / 2)`.
- [x] Beginner's Luck applies the existing Nature Tax resolver after the roll.
- [x] Beginner's Luck pre-check/spend treats Tap Nature as a separate +1 Persona cost.
- [x] Automatic trained-Skill advancement resets marks and posts a celebratory card.
- [x] Existing READY Skills are reconciled automatically and a new roll is not silently lost at the old mark cap.
- [x] Character Level remains immediate on cumulative Fate/Persona thresholds.
- [x] Level-up chat uses the new celebration presentation and an unlocked Talent chooser is offered asynchronously.
- [x] GM Dock stores custom coordinates in the current User flag `realm-guard.gmDockPosition` and has Reset Position.
- [x] GM Dock custom coordinates are clamped to the visible viewport.
- [x] Generic chat CSS targets the outer Foundry message containing `.realm-guard`, plus all RG/TB inner system cards.
- [x] v1.0.4 Recruitment Enemy House Rule files remain included.
- [x] No Actor/Item schema migration was introduced.

## Live QA required

Static QA cannot prove Foundry runtime focus behavior, drag persistence, visual chat contrast, actual roll resource deductions or event ordering. Complete `TEST_PROTOCOL_v1.0.5.md` in Foundry 13.351 before promoting v1.0.5 to GOLD/public manifest.
