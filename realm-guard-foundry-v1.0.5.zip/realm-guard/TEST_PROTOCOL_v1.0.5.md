# Realm Guard / Torchbearer v1.0.5 - Gameplay & UI Polish Hotfix QA

**Foundry target:** 13.351  
**Build status:** QA  
**Verified GOLD baseline:** v1.0.3  
**Includes:** v1.0.4 Recruitment House Rule UX  
**Migration:** none

## 1. Upgrade / smoke start

- [ ] Install v1.0.5 over an existing v1.0.3/v1.0.4 test World.
- [ ] World opens without a red console error.
- [ ] Existing Rangers/NPCs, Conditions, Inventory, Journals, Compendiums, progression and Recruitment data remain present.
- [ ] Sidebar Manual launcher and GM Dock tools still open.

## 2. Non-modal RG/TB windows

- [ ] Open a Skill Roll dialog and leave it open; click the Ranger sheet, chat and another Foundry control without closing the roll dialog.
- [ ] Open Recruitment and leave it open; interact with another Foundry window.
- [ ] Open Manual / GM tools / End Session / Content Studio representative windows and verify the rest of Foundry remains clickable.
- [ ] Returning to the open RG/TB window still allows its normal action/cancel flow.

## 3. Beginner's Luck + Tap Nature

Use an untrained Skill and a Ranger with Nature > 0 and enough Persona.

- [ ] Beginner's Luck Roll dialog offers Tap Nature.
- [ ] Pool construction visibly halves the Beginner's Luck pre-pool first, then adds Tap Nature dice afterward.
- [ ] Tap Nature costs exactly 1 additional Persona, separate from any 0-3 Persona dice selected.
- [ ] Within Nature + PASS causes no Tax.
- [ ] Against Nature + PASS causes 1 Tax.
- [ ] A failed tapped Beginner's Luck test taxes Nature by Margin of Failure.
- [ ] Resources/Circles still do not offer Tap Nature.
- [ ] Insufficient total Persona blocks the committed roll without spending resources.

## 4. Automatic Skill Advancement

- [ ] No manual `A`/Advance button is shown on trained Skills.
- [ ] Bring a Skill to one mark short of advancement.
- [ ] Roll the final required Pass/Fail: Skill rating increases automatically immediately.
- [ ] Pass/Fail marks reset for the new rating and new requirements are shown.
- [ ] A subsequent eligible test counts toward the new rating rather than being lost.
- [ ] Manual + correction that completes both requirements also triggers automatic advancement.
- [ ] Rating 6 remains the trained maximum.

## 5. Advancement chat presentation

- [ ] Automatic Skill Advancement posts a dark, clearly readable congratulatory card.
- [ ] Actor name, Skill name, old -> new rating and new Pass/Fail requirements are visible.
- [ ] Card remains readable in the Foundry appearance that previously produced a white chat background.

## 6. Immediate Level Up + Talent

- [ ] Cross a cumulative spent Fate/Persona threshold during play.
- [ ] Character Level increases immediately; no End Session gate exists.
- [ ] A large dark `LEVEL UP!` congratulations card appears in chat.
- [ ] Old Level -> new Level is clearly visible.
- [ ] If an unclaimed Talent is unlocked, the Talent chooser opens after the level increase.
- [ ] Closing/cancelling the Talent chooser does not undo the Level; the Talent choice remains pending on the sheet.
- [ ] Selecting a Talent creates it once and normal Talent behavior remains intact.

## 7. Movable GM Dock

- [ ] GM can drag the Dock using the RG/TB grip.
- [ ] Dock stays within the visible viewport.
- [ ] Reload the World: Dock returns to the GM's saved custom position.
- [ ] A different user is not forced to use that position.
- [ ] Reset Position returns the Dock to its normal Hotbar-adjacent placement and persists after reload.
- [ ] Dock tools remain clickable after dragging/resetting.

## 8. Full chat presentation audit

Check representative system messages:

- [ ] Standard Skill/Ability roll.
- [ ] Versus roll.
- [ ] Beginner's Luck.
- [ ] Nature / Tap Nature.
- [ ] Fate/Open 6s.
- [ ] Help/Teamwork.
- [ ] Recovery / Conditions.
- [ ] Skill Advancement / Skill Learned.
- [ ] Level Up / Talent.
- [ ] Conflict.
- [ ] End Session / Turn Manager / GM Resource Admin / Content Studio or World Audit.
- [ ] RG/TB-generated messages use the dark system surface; no white outer Foundry card makes text unreadable.
- [ ] PASS/FAIL/status colors remain distinct and readable.

## 9. v1.0.4 Recruitment carry-forward

- [ ] `Enemy's People / Type` remains clear.
- [ ] House Rule is off by default.
- [ ] With House Rule off, printed-rule choices remain available and Servants of the Enemy are blocked.
- [ ] With House Rule on, Orc/Troll/Warg/Spider/Other servant can be selected and persisted.

## 10. Regression smoke

- [ ] Persona 0-3D still works and deducts exactly the committed amount.
- [ ] Teamwork uses Skill or Wise, never helper Trait.
- [ ] Nature wording remains Within / Against Nature descriptors.
- [ ] Solo Embodiment still works; group not-everyone guard remains.
- [ ] Conditions modify rolls correctly.
- [ ] Fate/Open 6s spends exactly 1 Fate.
- [ ] Inventory paper-doll remains usable.
- [ ] Create Ranger opens and completes.
- [ ] Conflict Engine, End Session and Start Next Session still function.

## Result

**Status:** [ ] PASS  [ ] FAIL  [ ] BLOCKED  
**Blocking bugs:**  
**Non-blocking notes:**  
**Approved as v1.0.5 GOLD:** [ ] YES  [ ] NO
