# Realm Guard / Torchbearer v1.0.4 - Recruitment Enemy House Rule QA

**Foundry target:** 13.351  
**Build status:** QA  
**Baseline:** v1.0.3 GOLD  
**Migration:** none

## 1. Upgrade / smoke start

- [ ] Install v1.0.4 over an existing v1.0.3 World.
- [ ] World opens without a red console error.
- [ ] Existing Rangers/NPCs, Conditions, Inventory, Journals and Compendiums remain present.
- [ ] v1.0.3 Persona, Teamwork, Nature wording, solo Embodiment and chat contrast remain intact.

## 2. Recruitment - printed Realm Guard default

Open **Create Ranger** and reach Step 9: Lineage & Relationships.

- [ ] The House Rule checkbox is visible and **off by default**.
- [ ] The checkbox reads `Allow Servants of the Enemy as personal Enemies (House Rule)`.
- [ ] The Enemy selector is labelled `Enemy's People / Type`.
- [ ] Explanatory text makes clear that the field describes who/what the recurring personal Enemy is.
- [ ] Free Peoples remain available: Dúnadan, Dwarf, Elf, Hobbit and Man.
- [ ] Selecting a servant choice while the House Rule is off is blocked with a clear warning.

## 3. Recruitment - House Rule enabled

- [ ] Enable `Allow Servants of the Enemy as personal Enemies (House Rule)`.
- [ ] Orc can be selected and Recruitment can proceed.
- [ ] Troll can be selected and Recruitment can proceed.
- [ ] Warg can be selected and Recruitment can proceed.
- [ ] Spider can be selected and Recruitment can proceed.
- [ ] `Other servant of the Enemy` can be selected and Recruitment can proceed.
- [ ] Review & Create visibly identifies that the House Rule was enabled.
- [ ] The created Ranger stores the selected Enemy normally.
- [ ] Recruitment metadata stores `recruitmentEnemyHouseRule: true`.

## 4. House Rule off / normal Enemy

- [ ] Leave the House Rule off and choose a normal Free Peoples Enemy.
- [ ] Recruitment completes normally.
- [ ] Recruitment metadata stores `recruitmentEnemyHouseRule: false`.

## 5. Regression smoke

- [ ] Mentor validation still works by Station.
- [ ] Friend fields still validate normally.
- [ ] House/Lineage and House Insignia still validate normally.
- [ ] Created Ranger opens and all existing Recruitment-created data remains intact.

## Result

**Status:** [ ] PASS  [ ] FAIL  [ ] BLOCKED  
**Blocking bugs:**  
**Non-blocking notes:**  
**Approved as v1.0.4 GOLD:** [ ] YES  [ ] NO
