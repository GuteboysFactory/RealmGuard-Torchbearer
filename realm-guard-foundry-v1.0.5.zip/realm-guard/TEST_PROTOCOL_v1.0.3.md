# Realm Guard / Torchbearer v1.0.3 - GM Playtest Hotfix QA

**Foundry target:** 13.351  
**Build status:** QA  
**Baseline:** v1.0.2  
**Migration:** none

## 1. Upgrade / smoke start

- [ ] Install v1.0.3 over an existing v1.0.2 test World.
- [ ] World opens without a red console error.
- [ ] Existing Ranger/NPC data, Conditions, Inventory, Journals and Compendiums remain present.
- [ ] Sidebar book icon still opens Manual & Rules Reference.

## 2. Persona 0-3D

Use a Ranger with at least 3 Persona.

- [ ] Open a normal trained Skill roll. `Persona dice` offers 0, 1, 2 and 3 up to the amount actually available.
- [ ] Select 0 Persona: pool gains +0D and Persona does not change.
- [ ] Select 2 Persona: pool gains +2D and exactly 2 Persona are deducted after the committed roll.
- [ ] Select 3 Persona: pool gains +3D and exactly 3 Persona are deducted.
- [ ] If only 1 Persona remains, values 2 and 3 are not offered.
- [ ] Cancel before rolling: no Persona are spent.
- [ ] Beginner's Luck: selected Persona dice are added **after** halving.
- [ ] Ability/Nature/Versus flow accepts the same 0-3 Persona choice.
- [ ] Tap Nature/Double-Tap Nature still adds its separate Persona cost; insufficient total Persona blocks the roll before spending.
- [ ] Quick NPC Roll supports 0-3 Persona.
- [ ] Conflict roll Persona selector supports 0-3 and deducts the selected amount once.

## 3. Help / Teamwork rule correction

Use two Ranger tokens on the same Scene.

- [ ] Open a roll for Ranger A.
- [ ] Ranger B helper menu shows trained **Skills** and **Wises**, but no Traits.
- [ ] Select a Skill source: Ranger A receives +1D and chat identifies the helper/source.
- [ ] Select a Wise source: Ranger A receives +1D and chat identifies it as Wise.
- [ ] The helper text says Skill or Wise and explains I Am Wise.
- [ ] Afraid Rangers remain unavailable as helpers.

## 4. Nature wording

- [ ] Open a normal Skill/Ability roll where Tap Nature is available.
- [ ] The scope control is labelled `Test is`.
- [ ] Options read `Within Nature descriptors` and `Against Nature descriptors`.
- [ ] Direct Nature rolls use the same clear wording.
- [ ] Tax behavior itself is unchanged.

## 5. Solo Embodiment

Use an End of Session with exactly one participating Ranger.

- [ ] Select Embodiment for the sole Ranger.
- [ ] Review Awards proceeds; it is not rejected as "everyone".
- [ ] Approve Persona and Finish Session; Embodiment is included exactly once.
- [ ] Repeat with two participating Rangers and select Embodiment for both: the not-everyone guard still blocks it.
- [ ] With two or more Rangers, Embodiment may still be awarded to a proper subset.
- [ ] MVP and Workhorse restrictions remain unchanged.

## 6. Chat contrast

Test with the Foundry chat/sidebar appearance that previously produced white-on-white text.

- [ ] Advance a Skill and inspect the `ADVANCEMENT` card: text is readable against a dark Realm Guard card.
- [ ] Standard roll card remains readable.
- [ ] End of Session / Turn / GM / Talent or other available Realm Guard chat cards remain readable.
- [ ] PASS/FAIL status colors remain distinct.

## 7. Regression smoke

- [ ] Conditions still modify rolls (e.g. Injured -1D where applicable).
- [ ] Fate/Open 6s still works and spends exactly 1 Fate.
- [ ] Learning/Advancement still records once.
- [ ] Recovery still functions and failed Recovery does not create an extra twist/Condition.
- [ ] Inventory paper-doll remains usable.
- [ ] Create Ranger opens.
- [ ] End Session and Start Next Session still work.

## Result

**Status:** [ ] PASS  [ ] FAIL  [ ] BLOCKED  
**Blocking bugs:**  
**Non-blocking notes:**  
**Approved as v1.0.3 GOLD:** [ ] YES  [ ] NO
