# Realm Guard / Torchbearer for Foundry VTT

**Version:** 1.0.2 - Sidebar Manual UI Hotfix  
**Target:** Foundry VTT 13.351  
**Status:** QA / v1.0.2 UI hotfix  
**Verified GOLD baseline:** v1.0.0

## v1.0.2 Sidebar Manual UI hotfix

The previous floating **RG/TB** pill has been removed. The global Manual & Rules Reference launcher is now an icon-only **book button inside Foundry's sidebar tab strip**, using Foundry's own `ui-control` styling where available. The button keeps the same manual-opening behavior and tooltip without floating over the canvas/chat area.

The v1.0.1 World Description behavior is retained: Foundry's native **Edit World > World Description** remains the single source for Join Page World Description text. No automatic World Description content is seeded.

## v1.0 identity

The visible system name is now **Realm Guard / Torchbearer**. The internal Foundry package id remains `realm-guard` so existing Worlds continue to identify the same game system after upgrading from the verified 0.x line.

This private game system deliberately combines:

1. **Realm Guard: Rangers of the North** rules where that hack defines/overrides play;
2. inherited **Mouse Guard RPG 2nd Edition** core mechanics where Realm Guard does not replace them;
3. selected compatible **Torchbearer 2nd Edition** ideas that were deliberately adopted; and
4. clearly marked **Realm Guard / Torchbearer Foundry expansions**.

The release is not presented as a one-to-one digital edition of any single source book.


## Join page presentation

v1.0.2 retains the v1.0.1 dedicated **Realm Guard / Torchbearer** world/login background and uses Foundry's native **World Description** as the authoritative Join Page text. The system manifest still declares the same artwork as the default background for new Realm Guard / Torchbearer Worlds. Existing Worlds keep their World data; the join-page theme is presentation-only and does not move, rewrite or auto-fill campaign content.

## Global Manual & Rules Reference

v1.0.2 provides an icon-only **book button in Foundry's sidebar** for every user. The manual can be opened while working elsewhere in Foundry instead of requiring a return to chat.

The integrated manual now has two layers:

- **Using the Foundry System** - where the tools live and how the implemented play loop works.
- **Rules Reference** - concise summaries of the rules and automation boundaries actually used by the system.

Rules are marked as:

- `RULE`
- `AUTOMATED`
- `GM CALL`
- `RG/TB FOUNDRY`

## Permanent Rules Reference Journal

On first GM load, v1.0 creates a player-readable Journal folder **Realm Guard / Torchbearer** and the Journal **Realm Guard / Torchbearer - Rules Reference** if it does not already exist.

Normal world loading does not overwrite an existing Rules Reference Journal.

The same v1.0 rules-reference definitions are used by the integrated manual and the seeded Journal.

Shipped text references:

- `SYSTEM_MANUAL.md`
- `RULES_REFERENCE.md`

## Existing v0.26 GOLD features retained

- Recruitment 2.0 / Create Ranger / Recruitment Guide
- Skills, Learning, Beginner's Luck, Nature, Traits, Wises, Teamwork, Fate/Persona
- Conditions, Recovery, Optional Turn Manager / Free Play
- Inventory & Gear paper-doll and Containers
- Tokens of Power
- Levels & Talents
- Card-driven Conflict Engine
- Quick NPC / compact NPC sheet / GM Control
- Starter Compendiums
- GM Content Studio
- End of Session
- World Health Audit
- non-destructive World upgrade/transfer policy

## Data preservation

v1.0 does not rename the internal system id and does not deliberately move/reset existing World data. Existing Actors, NPCs, Scenes, Journals, Items, Compendiums, Recruitment, Inventory, Conditions, Tokens, Talents and progression must remain intact.

Use `TEST_PROTOCOL_v1.0.2.md` for this patch QA. Promote v1.0.2 only after the sidebar launcher and regression checks pass in Foundry 13.351.

### Final v1.0 Join Game correction
v1.0.2 keeps the approved ultra-wide Realm Guard / Torchbearer release artwork while restoring Foundry's native World Description as the authoritative Join Page text source. Join Game layout styling aligns the live Foundry controls with the artwork without injecting campaign/system copy into the description panel.

## Project repository
Planned distribution repository: https://github.com/GuteboysFactory/RealmGuard-Torchbearer

The v1.0.2 package records the project URL only. Foundry `manifest` and `download` URLs should be enabled after the GitHub v1.0.2 Release and ZIP asset have actually been published.

### Join Page World Description
Realm Guard / Torchbearer v1.0.2 displays the description saved in Foundry under **Edit World > World Description**. If the GM leaves that field blank, the Join Page description content is intentionally blank. The system does not write to the World document.
