# Realm Guard / Torchbearer - Local Project Roadmap

**Foundry target:** 13.351  
**Verified GOLD baseline:** v1.0.0  
**Current QA:** v1.0.2 Sidebar Manual UI hotfix

## v1.0.2 patch scope

- Remove the floating RG/TB pill launcher from the upper-right workspace.
- Add an icon-only book launcher to Foundry's sidebar tab strip for all users.
- Preserve the same Manual & Rules Reference behavior and tooltip.
- Retain v1.0.1 Join Page / World Description behavior unchanged.
- Preserve all v1.0.0 gameplay/data behavior.
- No migration and no rule-source change.
- Gate: live Foundry 13.351 visual QA of sidebar placement plus Manual opening and a short regression smoke test.

## Rule-source precedence

1. Realm Guard rules where the hack overrides the base game.
2. Mouse Guard 2E for inherited core mechanics.
3. Torchbearer 2E only for selected compatible mechanics deliberately adopted by the project.
4. Explicit Realm Guard / Torchbearer Foundry expansions.

## Verified rebuilt line

- v0.15.x - End of Session / GM Dock - GOLD.
- v0.16.x - Turn Manager / Checks - GOLD.
- v0.17.x - Recovery 2.0 + Optional Turn Manager - cumulatively verified.
- v0.18.x - Inventory & Gear 2.0 / sheet UX - GOLD at v0.18.8.
- v0.19.x - Recruitment 2.0 / Create Ranger / Recruitment Guide - GOLD at v0.19.1.
- v0.20.x - Card-driven Conflict Engine - GOLD at v0.20.0.
- v0.21.x - NPC & GM Tools - GOLD at v0.21.3.
- v0.22.x - Tokens of Power - GOLD at v0.22.0.
- v0.23.x - Levels & Talents - GOLD at v0.23.0.
- v0.24.x - Starter Compendiums - GOLD at v0.24.0.
- v0.25.x - GM Content Studio - GOLD at v0.25.0.
- v0.26.x - Pre-v1.0 Audit / Manual / Hardening - GOLD at v0.26.0.
- **v1.0.0 - Realm Guard / Torchbearer first stable release - current QA / release candidate.**

Wises 2.0 remains deliberately omitted. Custom Roll remains deferred unless the project explicitly reopens it.

## v1.0.0 release scope

- Display rename to **Realm Guard / Torchbearer** while retaining internal system id `realm-guard` for World compatibility.
- System description documents the deliberate Realm Guard + Mouse Guard 2E + selected Torchbearer 2E rule mix and explicit Foundry expansions.
- Global player/GM Manual access available from the Foundry sidebar without returning to chat.
- Integrated practical Rules Reference with RULE / AUTOMATED / GM CALL / RG/TB FOUNDRY labels.
- Permanent player-readable Rules Reference Journal seeded non-destructively into the World.
- Shipped `SYSTEM_MANUAL.md` and `RULES_REFERENCE.md`.
- v1.0 World Health Audit branding/version alignment.
- No new major tabletop subsystem and no destructive World migration.

## Release gate

v1.0.0 is promoted only after live Foundry 13.351 QA confirms:

- v0.26.0 GOLD World data survives the upgrade;
- all new branding/help/reference surfaces open correctly;
- Rules Reference Journal creates once and remains player-readable/non-destructive;
- the global help control remains reachable across normal workflows;
- World Health Audit reports v1.0.0 cleanly;
- representative Recruitment, roll, Inventory, Conflict, NPC/GM and End Session smoke regression passes.

## Post-v1.0 backlog

- Optional Custom Roll if explicitly reopened.
- Additional Starter Library content.
- Additional Talent/Token/NPC templates.
- Illustrated manual/screenshots if desired.
- Additional GM quality-of-life tools.
- Future Foundry major-version compatibility work.

## Version discipline

Every future version gets its own package-specific QA protocol. Stable 1.x patches remain non-destructive and are built from the latest verified GOLD baseline.
