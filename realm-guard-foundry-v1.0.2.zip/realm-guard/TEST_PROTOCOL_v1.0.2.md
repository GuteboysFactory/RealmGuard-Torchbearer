# Realm Guard / Torchbearer v1.0.2 - Sidebar Manual UI Hotfix Test Protocol

**Target:** Foundry VTT 13.351  
**Build:** v1.0.2  
**Scope:** Manual launcher placement only; no gameplay/data migration.

> **STOP RULE:** Reject v1.0.2 if the sidebar fails to render, any native sidebar tab becomes unusable, the book launcher overlaps the chat/canvas, the Manual fails to open, the internal system id changes, or a representative core smoke test regresses.

## A. Upgrade / identity

- [ ] Upgrade v1.0.1 -> v1.0.2 in a backed-up test World.
- [ ] Foundry reports **Realm Guard / Torchbearer v1.0.2**.
- [ ] Internal system id remains `realm-guard`.
- [ ] Existing Actors, Items, Journals, Scenes and Compendiums remain present.

## B. Sidebar launcher - primary fix

- [ ] The old floating pill-shaped **RG/TB** button is gone.
- [ ] A single icon-only **book** button appears inside Foundry's vertical sidebar tab strip.
- [ ] The button is aligned with the native sidebar buttons and does not cover chat, canvas or sidebar content.
- [ ] No duplicate book button appears after changing sidebar tabs.
- [ ] Hover tooltip reads **Realm Guard / Torchbearer · Manual & Rules Reference**.
- [ ] Clicking the book button opens **System Manual & Rules Reference**.
- [ ] Closing and reopening the Manual works.
- [ ] The launcher remains available after switching between Chat, Combat, Scenes, Actors, Items, Journals and Settings.
- [ ] Reloading the World creates exactly one sidebar launcher.

## C. Existing manual access regression

- [ ] Chat-side **System Manual** tool still opens the Manual where present.
- [ ] GM Dock Manual tool still opens the Manual for a GM.
- [ ] Rules Reference Journal link from the Manual still works.
- [ ] GM World Health Audit button from the Manual still works.

## D. Join Page / v1.0.1 regression

- [ ] Realm Guard / Torchbearer Join Page background still displays.
- [ ] With **Join Page Theme = Default**, Foundry's saved World Description still displays normally.
- [ ] Realm Guard does not auto-create or overwrite World Description text.

## E. Core smoke regression

- [ ] Open an existing Ranger sheet.
- [ ] Perform one ordinary trained Skill roll.
- [ ] Open Inventory & Gear.
- [ ] Open Conditions control.
- [ ] Open GM Control.
- [ ] World Health Audit reports system version **1.0.2** without a version-mismatch warning.

## Result

- [ ] **PASS / GOLD**
- [ ] **FAIL / FIX REQUIRED**

Notes:
