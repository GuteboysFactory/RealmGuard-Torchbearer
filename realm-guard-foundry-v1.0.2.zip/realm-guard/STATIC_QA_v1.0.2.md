# Realm Guard / Torchbearer v1.0.2 - Static QA

**Target:** Foundry VTT 13.351  
**Build:** v1.0.2  
**Scope:** Sidebar Manual UI hotfix

## Result

**PASS - ready for live Foundry v1.0.2 QA.**

## Verified

- `system.json` reports `1.0.2`, retains internal id `realm-guard`, title `Realm Guard / Torchbearer`, and Foundry target 13.351.
- Runtime initialization, Rules Reference release label, integrated Manual version label, and World Health Audit expectation are aligned to `1.0.2`.
- All shipped `.mjs`/`.js` files pass `node --check`.
- The old floating launcher implementation is removed: no `rg-global-help-button`, `ensureGlobalHelpButton`, or `document.body.append(button)` launcher path remains.
- The replacement launcher is icon-only and created as `ui-control rg-sidebar-manual-button`.
- The launcher is inserted into the actual sidebar tabs container, preferring `#sidebar-tabs` / the v13 sidebar `tabs` application part and using native `data-tab` entries as a robust fallback anchor.
- The launcher retains the existing Manual & Rules Reference click behavior, tooltip and ARIA label.
- No World Description mutation or automatic seeding code is present.
- No gameplay/data migration is introduced.
- `TEST_PROTOCOL_v1.0.2.md` is included; v1.0.1 version-specific QA files are not carried forward.

## Live QA still required

Static checks cannot prove the exact visual alignment inside the running Foundry 13.351 client. Live QA must confirm:

1. the book icon sits in the vertical native sidebar strip;
2. the old RG/TB pill is absent;
3. no native sidebar tab is displaced or broken;
4. the Manual opens from the new icon;
5. no duplicate launcher appears after tab changes/reload;
6. representative v1.0.1 regression smoke tests pass.
